<!DOCTYPE html>

<html class="light" lang="en"><head>
<meta charset="utf-8"/>
<meta content="width=device-width, initial-scale=1.0" name="viewport"/>
<title>Khu Wooden House - Accommodations</title>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&amp;display=swap" rel="stylesheet"/>
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&amp;display=swap" rel="stylesheet"/>
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&amp;display=swap" rel="stylesheet"/>
<script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
<script id="tailwind-config">
        tailwind.config = {
            darkMode: "class",
            theme: {
                extend: {
                    colors: {
                        "primary": "#13ec13",
                        "background-light": "#f6f8f6",
                        "background-dark": "#102210",
                    },
                    fontFamily: {
                        "display": ["Plus Jakarta Sans", "sans-serif"]
                    },
                    borderRadius: {"DEFAULT": "0.25rem", "lg": "0.5rem", "xl": "0.75rem", "full": "9999px"},
                },
            },
        }
    </script>
<style>
        .material-symbols-outlined {
            font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24;
        }
        /* Custom scrollbar for gallery if needed */
        .hide-scroll::-webkit-scrollbar {
            display: none;
        }
        .hide-scroll {
            -ms-overflow-style: none;
            scrollbar-width: none;
        }
    </style>
</head>
<body class="bg-background-light dark:bg-background-dark font-display text-[#0d1b0d] dark:text-[#f8fcf8] antialiased">
<!-- Top Navigation -->
<header class="sticky top-0 z-50 w-full border-b border-[#e7f3e7] dark:border-[#1a331a] bg-background-light/95 dark:bg-background-dark/95 backdrop-blur-sm">
<div class="flex items-center justify-between px-6 py-4 lg:px-10 max-w-[1440px] mx-auto">
<div class="flex items-center gap-4">
<div class="flex items-center gap-2 text-primary">
<span class="material-symbols-outlined text-3xl">forest</span>
</div>
<h2 class="text-xl font-bold tracking-tight text-[#0d1b0d] dark:text-white">Khu Retreats</h2>
</div>
<!-- Desktop Menu -->
<div class="hidden md:flex flex-1 justify-end gap-8 items-center">
<nav class="flex items-center gap-8">
<a class="text-sm font-medium hover:text-primary transition-colors" href="#">Stays</a>
<a class="text-sm font-medium hover:text-primary transition-colors" href="#">Experiences</a>
<a class="text-sm font-medium hover:text-primary transition-colors" href="#">About Us</a>
<a class="text-sm font-medium hover:text-primary transition-colors" href="#">Contact</a>
</nav>
<div class="flex gap-3">
<button class="flex items-center justify-center rounded-lg h-10 px-4 bg-transparent hover:bg-[#e7f3e7] dark:hover:bg-[#1a331a] text-sm font-bold transition-colors">
                        Sign In
                    </button>
<button class="flex items-center justify-center rounded-lg h-10 px-5 bg-primary hover:bg-opacity-90 text-[#0d1b0d] text-sm font-bold transition-colors shadow-sm">
                        Join
                    </button>
</div>
</div>
<!-- Mobile Menu Icon -->
<button class="md:hidden text-[#0d1b0d] dark:text-white">
<span class="material-symbols-outlined">menu</span>
</button>
</div>
</header>
<main class="w-full max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 py-6">
<!-- Breadcrumbs -->
<div class="flex flex-wrap items-center gap-2 text-sm font-medium text-[#4c9a4c] mb-6">
<a class="hover:underline" href="#">Home</a>
<span class="text-[#0d1b0d]/40 dark:text-white/40">/</span>
<a class="hover:underline" href="#">Accommodations</a>
<span class="text-[#0d1b0d]/40 dark:text-white/40">/</span>
<span class="text-[#0d1b0d] dark:text-white">Khu Wooden House</span>
</div>
<!-- Title Section -->
<div class="flex flex-col gap-4 mb-6">
<div class="flex flex-col md:flex-row md:justify-between md:items-start gap-4">
<div>
<h1 class="text-3xl md:text-4xl font-black tracking-tight text-[#0d1b0d] dark:text-white mb-2">
                        Khu Wooden House
                    </h1>
<div class="flex items-center gap-2 text-sm text-[#0d1b0d]/80 dark:text-white/80">
<span class="flex items-center gap-1 font-bold">
<span class="material-symbols-outlined text-primary text-lg" style="font-variation-settings: 'FILL' 1;">star</span>
                            4.92
                        </span>
<span>·</span>
<a class="underline font-semibold hover:text-primary" href="#reviews">128 reviews</a>
<span>·</span>
<span class="flex items-center gap-1">
                            Deep Forest Reserve, Highland Region
                        </span>
</div>
</div>
<div class="flex gap-3">
<button class="flex items-center gap-2 text-sm font-semibold px-4 py-2 rounded-lg hover:bg-[#e7f3e7] dark:hover:bg-[#1a331a] transition-colors">
<span class="material-symbols-outlined text-lg">share</span>
                        Share
                    </button>
<button class="flex items-center gap-2 text-sm font-semibold px-4 py-2 rounded-lg hover:bg-[#e7f3e7] dark:hover:bg-[#1a331a] transition-colors">
<span class="material-symbols-outlined text-lg">favorite</span>
                        Save
                    </button>
</div>
</div>
</div>
<!-- Image Gallery Grid -->
<div class="grid grid-cols-1 md:grid-cols-4 grid-rows-2 gap-3 h-[400px] md:h-[500px] rounded-2xl overflow-hidden mb-10 relative group/gallery">
<div class="md:col-span-2 md:row-span-2 relative h-full bg-neutral-200">
<div class="w-full h-full bg-cover bg-center hover:scale-105 transition-transform duration-500 cursor-pointer" data-alt="Exterior view of a modern wooden cabin in a misty forest" style="background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuDa1oyVnz9Doaz-4jtFIPkc_eDRgxyBk0uyU0sfRTQzTT_6vzQQn_bFfa59EzNtTKZJV_k_LK4Mv3v8EYGMfF9wGoNS7sLDEjeSgWQohMfAMZCW8xkESOHj40j9FwN6QQIr9J-T-FbcLWoU90HF9rDXvzxOGZphvgPkmTWSBZPzI2T3tDlgfmalp4c7jbxow1Imqr9c20mjQrE0uyjLfJ7W-wzI95qa5GLTQvma5f9j7sBBYR_kDRVeJMq0zxb6m-earjna9U3_cKA');"></div>
</div>
<div class="md:col-span-1 md:row-span-1 relative h-full bg-neutral-200">
<div class="w-full h-full bg-cover bg-center hover:scale-105 transition-transform duration-500 cursor-pointer" data-alt="Cozy living room interior with fireplace and large windows" style="background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuAFdzcRdSm5XT-nYMSD_rbz11kYyMOwAeuTNeQsmAbUGojFaOGpDZutgmVhlVUPFUlOLDnYTlPbDHE0GCInJmvQ8ku_2gP9HgoJpo3zwboSLfVZAER2B2S3sYd-VWP8eQh978iKC00QEqOE7SMHpgdvmSGonnesFCh2nkF6wUyitFhxZMai1a35FfhsWyevGSTWbMRfd3UlBJcVFKV7Fmvt4LXJ3JVoqEcPf-GLHtfVdI_C2BNyrH2fkJn_9OrAYmwtLRSCL-k2xR4');"></div>
</div>
<div class="md:col-span-1 md:row-span-1 relative h-full bg-neutral-200">
<div class="w-full h-full bg-cover bg-center hover:scale-105 transition-transform duration-500 cursor-pointer" data-alt="Minimalist bedroom with wooden walls and forest view" style="background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuBMaZLJsnS8SSoTtrSqCu0bM2F_Ui16WUWZ3KeEo_BPuHErySE-bqUCjaISrJNkmkI29ZsKwtOxM2JmVZOHbh7mZR80uSFs59ZG_Ju9Dv9R6lHJschUA1KxuRdUINwZ9uIURh5NF5AAsyXaCLzRy1E7fFafcr5Yj_aY5Rfrcwdghrlmxp45B3pUp22rP7Y-TCuvPMlO_M0L2IppCfrcIFmS3STwfn71EjdcjCw8U3jyXgtNFbnrwn_A7t3QA3CUqlKAjWK3RxbrPio');"></div>
</div>
<div class="md:col-span-1 md:row-span-1 relative h-full bg-neutral-200">
<div class="w-full h-full bg-cover bg-center hover:scale-105 transition-transform duration-500 cursor-pointer" data-alt="Modern kitchen detail with wooden countertops" style="background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuBaiM8xDIH5vlv19XTaOAOyS52vaNTava75Hd1IMfQMfL234AG1DQ2k70uKQ4nfdU9ca0vtXanOus5P6Z1aaQQ19Ec63haeMpdUmF_GrNWFKLM2IagE6OEBhONjNsr0F4riF4eqvvurH-FriaRmC9owoF3T8wKV1XBqdejog_bTZsmhrvaioOQxvmTPOvFyrqPr-PKzUbst9OorG5-1AkncmCo2ImsIUmwQpEax1TMxcjg3fvbcud20dbY5kegxwXOEisab2vfABIk');"></div>
</div>
<div class="md:col-span-1 md:row-span-1 relative h-full bg-neutral-200">
<div class="w-full h-full bg-cover bg-center hover:scale-105 transition-transform duration-500 cursor-pointer" data-alt="Wooden deck overlooking pine trees" style="background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuAC4YXDTvtuHpmkTjliXcnyOl1YSsO-lDLiYXvk7yNIbPT1g9ereV-JWHiEhE_QEAKpI8jwCovZ7RSjC1c6c09seFlXyoPd6tmA4lSU4jgurd5V8qweJRW3cbKG21xd3jaVUKZu0BTORdt9zNL8FP1f5KW59DsA1r1ssoF2K5T5AW0VHgFNP7eMaYI0FJ6oQrDrV8QVKFCY-G8Dy6dGE9aKckl1tujmxmhzv6QCO6wYxXK7vrLLWRtfYaVmnEHj8QN9fIVEckl1wFA');"></div>
<button class="absolute bottom-4 right-4 bg-white dark:bg-[#1a331a] text-xs font-bold px-3 py-2 rounded-lg shadow-md hover:scale-105 transition flex items-center gap-2 border border-gray-200 dark:border-gray-800">
<span class="material-symbols-outlined text-base">grid_view</span>
                    Show all photos
                </button>
</div>
</div>
<!-- Content Split Layout -->
<div class="grid grid-cols-1 lg:grid-cols-3 gap-12 relative">
<!-- Left Column: Details -->
<div class="lg:col-span-2 flex flex-col gap-10">
<!-- Quick Info Bar -->
<div class="flex justify-between items-center border-b border-[#e7f3e7] dark:border-[#1a331a] pb-8">
<div class="flex flex-col gap-1">
<h2 class="text-xl font-bold">Entire cabin hosted by Sarah</h2>
<span class="text-base text-[#0d1b0d]/70 dark:text-white/70">4 guests · 2 bedrooms · 3 beds · 1 bath</span>
</div>
<div class="size-14 rounded-full overflow-hidden bg-gray-200 border-2 border-primary p-0.5">
<div class="w-full h-full rounded-full bg-cover bg-center" data-alt="Portrait of the host Sarah" style="background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuD3W_7F2E4sqRpbFzNPgE3vmfcTBpFLLblPJjr_vmOeGWI6y9qTaMW41Sztty7AJobiVMt0Hdyh1uzX5FqIP9K7GhGW7B5n196DqLL-SF8pvNa0Eg_U3M-NXJanLzwrbmrGgMmXzD1fyFecIzsnDeyUEheEKEjlRwZ07Z5t0WImn-NYPfkPIQHneqc2-Wl5_iXyGgwtnP73jylXL7y1HAiCE6FK6S6esIvMZbo6xC5kEG_Lae9nX-OKLR_NoZKaSs-X7IwnKXsi5lc')"></div>
</div>
</div>
<!-- Highlights -->
<div class="flex flex-col gap-6">
<div class="flex gap-4">
<span class="material-symbols-outlined text-2xl mt-1 text-primary">psychology</span>
<div>
<h3 class="font-bold text-lg">Designed for disconnect</h3>
<p class="text-sm text-[#0d1b0d]/70 dark:text-white/70">No TV, limited cell service, but high-speed Starlink wifi if you really need it.</p>
</div>
</div>
<div class="flex gap-4">
<span class="material-symbols-outlined text-2xl mt-1 text-primary">location_on</span>
<div>
<h3 class="font-bold text-lg">Secluded location</h3>
<p class="text-sm text-[#0d1b0d]/70 dark:text-white/70">Nestled deep within the forest reserve, accessible only by a private gravel road.</p>
</div>
</div>
<div class="flex gap-4">
<span class="material-symbols-outlined text-2xl mt-1 text-primary">calendar_today</span>
<div>
<h3 class="font-bold text-lg">Free cancellation for 48 hours</h3>
<p class="text-sm text-[#0d1b0d]/70 dark:text-white/70">Get a full refund if you change your mind.</p>
</div>
</div>
</div>
<div class="border-b border-[#e7f3e7] dark:border-[#1a331a]"></div>
<!-- Description -->
<div>
<h2 class="text-2xl font-bold mb-4">About this space</h2>
<div class="space-y-4 text-base leading-relaxed text-[#0d1b0d]/80 dark:text-white/80">
<p>
                            Nestled deep within the forest reserve, the Khu Wooden House offers a unique blend of traditional craftsmanship and modern luxury. Designed with sustainable timber and large glass panels, the architecture invites the outside in, allowing you to wake up to the sound of birds and the scent of pine.
                        </p>
<p>
                            Perfect for couples or small families looking to disconnect from the city. The open-plan living area features a hanging fireplace, a fully equipped chef's kitchen, and floor-to-ceiling windows that frame the ancient woodland.
                        </p>
<p>
                            Step outside onto the expansive wraparound deck to enjoy your morning coffee, or unwind in the cedar wood hot tub under the stars.
                        </p>
</div>
<button class="mt-4 flex items-center gap-1 font-bold underline decoration-primary decoration-2 underline-offset-4 hover:opacity-80">
                        Show more <span class="material-symbols-outlined text-lg">chevron_right</span>
</button>
</div>
<div class="border-b border-[#e7f3e7] dark:border-[#1a331a]"></div>
<!-- Amenities -->
<div>
<h2 class="text-2xl font-bold mb-6">What this place offers</h2>
<div class="grid grid-cols-1 md:grid-cols-2 gap-y-4 gap-x-12">
<div class="flex items-center gap-4">
<span class="material-symbols-outlined text-2xl text-[#0d1b0d]/60 dark:text-white/60">wifi</span>
<span class="text-base">Fast wifi (Starlink)</span>
</div>
<div class="flex items-center gap-4">
<span class="material-symbols-outlined text-2xl text-[#0d1b0d]/60 dark:text-white/60">kitchen</span>
<span class="text-base">Kitchen</span>
</div>
<div class="flex items-center gap-4">
<span class="material-symbols-outlined text-2xl text-[#0d1b0d]/60 dark:text-white/60">directions_car</span>
<span class="text-base">Free parking on premises</span>
</div>
<div class="flex items-center gap-4">
<span class="material-symbols-outlined text-2xl text-[#0d1b0d]/60 dark:text-white/60">hot_tub</span>
<span class="text-base">Private hot tub</span>
</div>
<div class="flex items-center gap-4">
<span class="material-symbols-outlined text-2xl text-[#0d1b0d]/60 dark:text-white/60">deck</span>
<span class="text-base">Patio or balcony</span>
</div>
<div class="flex items-center gap-4">
<span class="material-symbols-outlined text-2xl text-[#0d1b0d]/60 dark:text-white/60">ac_unit</span>
<span class="text-base">Air conditioning</span>
</div>
<div class="flex items-center gap-4">
<span class="material-symbols-outlined text-2xl text-[#0d1b0d]/60 dark:text-white/60">fireplace</span>
<span class="text-base">Indoor fireplace</span>
</div>
<div class="flex items-center gap-4 line-through decoration-slate-400">
<span class="material-symbols-outlined text-2xl text-[#0d1b0d]/30 dark:text-white/30">tv</span>
<span class="text-base text-[#0d1b0d]/50 dark:text-white/50">Television</span>
</div>
</div>
<button class="mt-8 border border-black dark:border-white rounded-lg px-6 py-3 font-semibold hover:bg-black/5 dark:hover:bg-white/10 transition">
                        Show all 32 amenities
                    </button>
</div>
<div class="border-b border-[#e7f3e7] dark:border-[#1a331a]"></div>
<!-- Calendar Placeholder -->
<div>
<h2 class="text-2xl font-bold mb-2">5 nights in Highlands</h2>
<p class="text-sm text-[#0d1b0d]/60 dark:text-white/60 mb-6">Mar 15, 2024 - Mar 20, 2024</p>
<!-- Simple Calendar Grid Visual -->
<div class="w-full bg-[#f8fcf8] dark:bg-[#152a15] rounded-xl p-6 border border-[#e7f3e7] dark:border-[#1a331a]">
<div class="flex justify-between items-center mb-6">
<span class="font-bold">March 2024</span>
<div class="flex gap-4">
<span class="material-symbols-outlined cursor-pointer">chevron_left</span>
<span class="material-symbols-outlined cursor-pointer">chevron_right</span>
</div>
</div>
<div class="grid grid-cols-7 gap-2 text-center text-sm">
<div class="font-medium text-xs text-gray-500 mb-2">Su</div>
<div class="font-medium text-xs text-gray-500 mb-2">Mo</div>
<div class="font-medium text-xs text-gray-500 mb-2">Tu</div>
<div class="font-medium text-xs text-gray-500 mb-2">We</div>
<div class="font-medium text-xs text-gray-500 mb-2">Th</div>
<div class="font-medium text-xs text-gray-500 mb-2">Fr</div>
<div class="font-medium text-xs text-gray-500 mb-2">Sa</div>
<!-- Days -->
<div class="p-2 text-gray-400">26</div>
<div class="p-2 text-gray-400">27</div>
<div class="p-2 text-gray-400">28</div>
<div class="p-2 text-gray-400">29</div>
<div class="p-2">1</div>
<div class="p-2">2</div>
<div class="p-2">3</div>
<div class="p-2">4</div>
<div class="p-2">5</div>
<div class="p-2">6</div>
<div class="p-2">7</div>
<div class="p-2">8</div>
<div class="p-2">9</div>
<div class="p-2">10</div>
<div class="p-2">11</div>
<div class="p-2">12</div>
<div class="p-2">13</div>
<div class="p-2">14</div>
<div class="p-2 rounded-full bg-primary text-black font-bold">15</div>
<div class="p-2 bg-primary/20">16</div>
<div class="p-2 bg-primary/20">17</div>
<div class="p-2 bg-primary/20">18</div>
<div class="p-2 bg-primary/20">19</div>
<div class="p-2 rounded-full bg-primary text-black font-bold">20</div>
<div class="p-2">21</div>
<div class="p-2">22</div>
<div class="p-2">23</div>
<div class="p-2">24</div>
<div class="p-2 line-through text-gray-400">25</div>
<div class="p-2 line-through text-gray-400">26</div>
<div class="p-2 line-through text-gray-400">27</div>
<div class="p-2 line-through text-gray-400">28</div>
</div>
<div class="flex justify-between items-center mt-4 pt-4 border-t border-[#e7f3e7] dark:border-[#1a331a]">
<button class="font-bold underline text-sm">Clear dates</button>
</div>
</div>
</div>
</div>
<!-- Right Column: Booking Widget (Sticky) -->
<div class="lg:col-span-1 relative">
<div class="sticky top-28 w-full">
<div class="bg-white dark:bg-[#152a15] rounded-2xl shadow-xl border border-[#e7f3e7] dark:border-[#1a331a] p-6">
<div class="flex justify-between items-end mb-6">
<div>
<span class="text-2xl font-bold">$250</span>
<span class="text-[#0d1b0d]/60 dark:text-white/60"> night</span>
</div>
<div class="flex items-center gap-1 text-sm">
<span class="material-symbols-outlined text-primary text-sm" style="font-variation-settings: 'FILL' 1;">star</span>
<span class="font-bold">4.92</span>
<span class="text-gray-400">·</span>
<span class="text-gray-500 underline decoration-gray-400">128 reviews</span>
</div>
</div>
<!-- Date/Guest Inputs -->
<div class="border border-gray-300 dark:border-gray-600 rounded-xl overflow-hidden mb-4">
<div class="flex border-b border-gray-300 dark:border-gray-600">
<div class="flex-1 p-3 border-r border-gray-300 dark:border-gray-600">
<label class="block text-[10px] font-bold uppercase tracking-wider text-[#0d1b0d] dark:text-white">Check-in</label>
<div class="text-sm">3/15/2024</div>
</div>
<div class="flex-1 p-3">
<label class="block text-[10px] font-bold uppercase tracking-wider text-[#0d1b0d] dark:text-white">Check-out</label>
<div class="text-sm">3/20/2024</div>
</div>
</div>
<div class="p-3 relative">
<label class="block text-[10px] font-bold uppercase tracking-wider text-[#0d1b0d] dark:text-white">Guests</label>
<div class="text-sm flex justify-between items-center">
<span>2 guests</span>
<span class="material-symbols-outlined text-xl">expand_more</span>
</div>
</div>
</div>
<button class="w-full bg-primary hover:bg-[#0fd60f] text-[#0d1b0d] font-bold py-3.5 rounded-xl text-lg transition-all transform active:scale-[0.98] mb-4">
                            Reserve
                        </button>
<p class="text-center text-sm text-[#0d1b0d]/60 dark:text-white/60 mb-6">You won't be charged yet</p>
<!-- Price Breakdown -->
<div class="flex flex-col gap-3 text-sm md:text-base">
<div class="flex justify-between text-[#0d1b0d]/80 dark:text-white/80">
<span class="underline decoration-gray-300">$250 x 5 nights</span>
<span>$1,250</span>
</div>
<div class="flex justify-between text-[#0d1b0d]/80 dark:text-white/80">
<span class="underline decoration-gray-300">Cleaning fee</span>
<span>$75</span>
</div>
<div class="flex justify-between text-[#0d1b0d]/80 dark:text-white/80">
<span class="underline decoration-gray-300">Khu Service fee</span>
<span>$140</span>
</div>
</div>
<div class="my-6 border-t border-[#e7f3e7] dark:border-[#1a331a]"></div>
<div class="flex justify-between font-bold text-lg">
<span>Total before taxes</span>
<span>$1,465</span>
</div>
</div>
<div class="mt-4 flex justify-center gap-2 items-center text-sm text-[#0d1b0d]/50 dark:text-white/50">
<span class="material-symbols-outlined text-base">flag</span>
<a class="underline hover:text-[#0d1b0d] dark:hover:text-white" href="#">Report this listing</a>
</div>
</div>
</div>
</div>
<div class="border-b border-[#e7f3e7] dark:border-[#1a331a] my-12"></div>
<!-- Reviews Section -->
<section class="mb-12" id="reviews">
<div class="flex items-center gap-2 mb-8">
<span class="material-symbols-outlined text-primary text-3xl" style="font-variation-settings: 'FILL' 1;">star</span>
<h2 class="text-2xl font-bold">4.92 · 128 reviews</h2>
</div>
<div class="grid grid-cols-1 md:grid-cols-2 gap-8">
<!-- Review 1 -->
<div class="flex flex-col gap-4">
<div class="flex items-center gap-3">
<div class="size-12 rounded-full bg-gray-200 overflow-hidden">
<div class="w-full h-full bg-cover bg-center" data-alt="Reviewer avatar" style="background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuCIuDmbaeWkddKXGutG8o0Ndfx6Trt0hdk_aiRyecdlJ6Gajwc2KL9TK2BwteORB7YA2MZ0yujcolLKNReLGe8jQM2t6Y73gep8TeLKAiRytOoJNmX7JoZBpAWSfXMbeQd0BsNByAaJiwZh7_ZGiwQjMX5I5lR0IqwuyQg0f4WuQMOoDoTFPjEF5Ao5TEgpqKZrvJm3eup1DTvWXVohf4qaDKWEErMv9-9g91RuQo-G1EWt85spNsp_mw4df88wtoqKLi6CQo3YkfY')"></div>
</div>
<div>
<div class="font-bold">Michael</div>
<div class="text-sm text-[#0d1b0d]/60 dark:text-white/60">December 2023</div>
</div>
</div>
<p class="text-[#0d1b0d]/80 dark:text-white/80 leading-relaxed">
                        "Absolutely stunning property. The pictures don't do it justice. We loved the quiet mornings on the deck and the evenings by the fire. The kitchen was stocked with everything we needed to cook big meals. Highly recommend!"
                    </p>
</div>
<!-- Review 2 -->
<div class="flex flex-col gap-4">
<div class="flex items-center gap-3">
<div class="size-12 rounded-full bg-gray-200 overflow-hidden">
<div class="w-full h-full bg-cover bg-center" data-alt="Reviewer avatar" style="background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuAxTGKPB_3H4V8sMME6FzJH-1p8M68N0971xe8hsunrRjU0F1Ir-N2dMWvXLPNh9Q7U2zovBONJJiNyV3K50FfE0XSij58q4ez7y_glcT0TYadiTmJBLU0qOmjwERiGsU0e8A0XEu15tmrtrx7_0pxF31ws1oWxqkuL_R_DR_EQTcBsytFlLLIqgzzBwMYLwJ7LEVVNr8PE2cFrVX4OZfO8uvhjYKP_xntP78gf9O9wZmkm3gPTNjnn0SJHjs2BWplqLZL-rpPv-yQ')"></div>
</div>
<div>
<div class="font-bold">Jessica</div>
<div class="text-sm text-[#0d1b0d]/60 dark:text-white/60">January 2024</div>
</div>
</div>
<p class="text-[#0d1b0d]/80 dark:text-white/80 leading-relaxed">
                        "A perfect escape from the city. The wifi was surprisingly fast for being so deep in the woods, which was great since I had to take a couple of calls. But mostly, we just unplugged and enjoyed nature."
                    </p>
</div>
</div>
<button class="mt-8 border border-black dark:border-white rounded-lg px-6 py-3 font-semibold hover:bg-black/5 dark:hover:bg-white/10 transition">
                Show all 128 reviews
            </button>
</section>
<div class="border-b border-[#e7f3e7] dark:border-[#1a331a] my-12"></div>
<!-- Map Section -->
<section class="mb-12">
<h2 class="text-2xl font-bold mb-2">Where you'll be</h2>
<p class="text-[#0d1b0d]/70 dark:text-white/70 mb-6">Highland Region, Country</p>
<div class="w-full h-[480px] rounded-xl bg-gray-200 relative overflow-hidden group">
<div class="w-full h-full bg-cover bg-center" data-alt="Map view showing the location of the cabin in a dense forest region" data-location="Highland Region Map View" style="background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuDFrvITJw83pqzEk_7VctE26T1LCJR8EYOMhNTpSHmWZPzcXjKjvxeNtF8GWm5xIHg58ryuzx37bvm0EnORRAi6iqPObc-ZxQ1T77wN2sN15eVEWt0-THk7Z4MUn4WofCy0el2-ZCifbiggQGlU8l2OyatXqHjVRV3oOSFK-LaNGt0k6d68ZodFA41WR0Stazy6RQvx6Pxb-obHoQRQHZXVIpRCtVRk_-sXpsrzJOqSlueaCtQue8vZMi38qTCO6GD0vfWwbWEiR6w'); filter: grayscale(20%);">
</div>
<!-- Map Pin -->
<div class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center">
<div class="size-12 bg-primary rounded-full flex items-center justify-center shadow-lg animate-bounce">
<span class="material-symbols-outlined text-white text-3xl" style="font-variation-settings: 'FILL' 1;">home</span>
</div>
<div class="mt-2 bg-white dark:bg-[#1a331a] px-4 py-2 rounded-lg shadow-lg font-bold text-sm">
                        Exact location provided after booking
                    </div>
</div>
<div class="absolute bottom-4 right-4 flex gap-2">
<button class="bg-white dark:bg-[#1a331a] p-2 rounded shadow hover:bg-gray-100">
<span class="material-symbols-outlined">add</span>
</button>
<button class="bg-white dark:bg-[#1a331a] p-2 rounded shadow hover:bg-gray-100">
<span class="material-symbols-outlined">remove</span>
</button>
</div>
</div>
<div class="mt-6">
<h3 class="font-bold text-lg mb-2">Highland Region</h3>
<p class="text-[#0d1b0d]/70 dark:text-white/70 max-w-3xl">
                    The cabin is located in the heart of the Highland Forest Reserve. You'll be surrounded by towering pine trees and hiking trails. The nearest town is a 20-minute drive away, offering local markets, cafes, and artisanal shops.
                </p>
</div>
</section>
</main>
<!-- Footer -->
<footer class="bg-[#f8fcf8] dark:bg-[#0c1a0c] border-t border-[#e7f3e7] dark:border-[#1a331a] py-12">
<div class="max-w-[1280px] mx-auto px-6 lg:px-8">
<div class="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
<div>
<h3 class="font-bold mb-4">Support</h3>
<ul class="space-y-3 text-sm text-[#0d1b0d]/70 dark:text-white/70">
<li><a class="hover:underline" href="#">Help Center</a></li>
<li><a class="hover:underline" href="#">AirCover</a></li>
<li><a class="hover:underline" href="#">Anti-discrimination</a></li>
<li><a class="hover:underline" href="#">Disability support</a></li>
<li><a class="hover:underline" href="#">Cancellation options</a></li>
</ul>
</div>
<div>
<h3 class="font-bold mb-4">Hosting</h3>
<ul class="space-y-3 text-sm text-[#0d1b0d]/70 dark:text-white/70">
<li><a class="hover:underline" href="#">Khu your home</a></li>
<li><a class="hover:underline" href="#">AirCover for Hosts</a></li>
<li><a class="hover:underline" href="#">Hosting resources</a></li>
<li><a class="hover:underline" href="#">Community forum</a></li>
<li><a class="hover:underline" href="#">Hosting responsibly</a></li>
</ul>
</div>
<div>
<h3 class="font-bold mb-4">Khu Retreats</h3>
<ul class="space-y-3 text-sm text-[#0d1b0d]/70 dark:text-white/70">
<li><a class="hover:underline" href="#">Newsroom</a></li>
<li><a class="hover:underline" href="#">New features</a></li>
<li><a class="hover:underline" href="#">Careers</a></li>
<li><a class="hover:underline" href="#">Investors</a></li>
<li><a class="hover:underline" href="#">Gift cards</a></li>
</ul>
</div>
<div>
<div class="flex flex-col gap-4">
<button class="bg-primary hover:bg-[#0fd60f] text-[#0d1b0d] font-bold py-3 rounded-lg text-sm w-full transition-colors">
                            Become a Host
                        </button>
<p class="text-xs text-[#0d1b0d]/50 dark:text-white/50">
                            Earn extra income and unlock new opportunities by sharing your space.
                        </p>
</div>
</div>
</div>
<div class="border-t border-[#e7f3e7] dark:border-[#1a331a] pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
<div class="flex items-center gap-2 text-sm text-[#0d1b0d]/70 dark:text-white/70">
<span>© 2024 Khu Retreats, Inc.</span>
<span>·</span>
<a class="hover:underline" href="#">Privacy</a>
<span>·</span>
<a class="hover:underline" href="#">Terms</a>
<span>·</span>
<a class="hover:underline" href="#">Sitemap</a>
</div>
<div class="flex gap-4">
<span class="material-symbols-outlined cursor-pointer hover:text-primary transition-colors">language</span>
<span class="text-sm font-bold cursor-pointer hover:text-primary transition-colors">English (US)</span>
<span class="text-sm font-bold cursor-pointer hover:text-primary transition-colors">$ USD</span>
</div>
</div>
</div>
</footer>
</body></html>