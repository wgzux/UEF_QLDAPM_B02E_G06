<!DOCTYPE html>

<html class="dark" lang="en"><head>
<meta charset="utf-8"/>
<meta content="width=device-width, initial-scale=1.0" name="viewport"/>
<title>Lux Weddings - Large Event Experiences</title>
<script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
<link href="https://fonts.googleapis.com" rel="preconnect"/>
<link crossorigin="" href="https://fonts.gstatic.com" rel="preconnect"/>
<link href="https://fonts.googleapis.com/css2?family=Noto+Serif:ital,wght@0,100..900;1,100..900&amp;family=Noto+Sans:ital,wght@0,100..900;1,100..900&amp;display=swap" rel="stylesheet"/>
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&amp;display=swap" rel="stylesheet"/>
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&amp;display=swap" rel="stylesheet"/>
<script id="tailwind-config">
        tailwind.config = {
            darkMode: "class",
            theme: {
            extend: {
                colors: {
                "primary": "#d41121",
                "background-light": "#f8f6f6",
                "background-dark": "#221012",
                "surface-dark": "#33191b",
                "border-dark": "#482326",
                },
                fontFamily: {
                "display": ["Noto Serif", "serif"],
                "body": ["Noto Sans", "sans-serif"],
                },
                borderRadius: {"DEFAULT": "0.25rem", "lg": "0.5rem", "xl": "0.75rem", "full": "9999px"},
            },
            },
        }
    </script>
<style>
        body { font-family: "Noto Sans", sans-serif; }
        h1, h2, h3, h4, h5, h6 { font-family: "Noto Serif", serif; }
        .glass-nav {
            background: rgba(34, 16, 18, 0.85);
            backdrop-filter: blur(12px);
        }
    </style>
</head>
<body class="bg-background-light dark:bg-background-dark text-slate-900 dark:text-white antialiased">
<!-- Top Navigation -->
<header class="fixed top-0 w-full z-50 glass-nav border-b border-border-dark">
<div class="max-w-[1280px] mx-auto px-4 sm:px-10 py-4 flex items-center justify-between">
<div class="flex items-center gap-3">
<div class="size-8 text-primary">
<span class="material-symbols-outlined text-3xl">diamond</span>
</div>
<h2 class="text-white text-xl font-bold tracking-tight">LUX WEDDINGS</h2>
</div>
<nav class="hidden md:flex items-center gap-8">
<a class="text-white/80 hover:text-white text-sm font-medium transition-colors" href="#">Venues</a>
<a class="text-white/80 hover:text-white text-sm font-medium transition-colors" href="#">Packages</a>
<a class="text-white/80 hover:text-white text-sm font-medium transition-colors" href="#">Menu</a>
<a class="text-white/80 hover:text-white text-sm font-medium transition-colors" href="#">Gallery</a>
</nav>
<div class="flex items-center gap-4">
<button class="bg-primary hover:bg-red-700 text-white px-5 py-2.5 rounded-lg text-sm font-bold transition-all shadow-lg shadow-red-900/20">
                    Book Consultation
                </button>
</div>
</div>
</header>
<!-- Hero Section -->
<section class="relative min-h-screen flex items-center justify-center overflow-hidden">
<!-- Background Image with Overlay -->
<div class="absolute inset-0 z-0 bg-cover bg-center bg-no-repeat" data-alt="Grand ballroom setup with chandeliers and floral arrangements" style='background-image: linear-gradient(rgba(34, 17, 18, 0.3), rgba(34, 17, 18, 0.7)), url("https://lh3.googleusercontent.com/aida-public/AB6AXuCxYOn6d4II7PgbsEGatm4qcFlT3W0SBabTSe9WU-u055HlvpSlA3C6nnk8rgz61Z4Vr_mJr1MtK2gAh40NpwbsCUwSIKIuXZHkJJdYLnLENcQi9BWv8DgT_VkLfciBENYM72xigjGGVXqAYJXUYHePCtbI6z9mNxtsSxi_Qfr2aUxkhIWESionyqs6DlkPKGupRK8rcQg-ww_PDwJcyBPdr2wTj-mw29x_LpH_7bkT4l9__myiL-YJhaxWFMKds0BLptZnDLxzRC4");'>
</div>
<div class="relative z-10 container mx-auto px-4 text-center mt-20">
<span class="inline-block py-1 px-3 rounded-full bg-primary/20 border border-primary/30 text-white text-xs font-semibold tracking-wider mb-6 uppercase backdrop-blur-sm">Imperial Luxury Collection</span>
<h1 class="text-5xl md:text-7xl lg:text-8xl font-black text-white mb-6 tracking-tight drop-shadow-xl">
                The Wedding of <br class="hidden md:block"/> a Lifetime
            </h1>
<p class="text-white/90 text-lg md:text-xl font-light max-w-2xl mx-auto mb-10 font-body leading-relaxed">
                Experience grandeur and timeless elegance for your celebration. Our large-scale venues accommodate up to 1,500 guests without compromising on luxury or intimacy.
            </p>
<div class="flex flex-col sm:flex-row gap-4 justify-center items-center">
<button class="h-12 px-8 rounded-lg bg-primary hover:bg-red-700 text-white font-bold text-base transition-all shadow-lg shadow-red-900/40 w-full sm:w-auto">
                    Start Planning
                </button>
<button class="h-12 px-8 rounded-lg bg-white/10 hover:bg-white/20 text-white border border-white/20 font-bold text-base transition-all backdrop-blur-md w-full sm:w-auto flex items-center justify-center gap-2">
<span class="material-symbols-outlined text-sm">play_circle</span> View Gallery
                </button>
</div>
</div>
<!-- Scroll Down Indicator -->
<div class="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce text-white/50">
<span class="material-symbols-outlined">keyboard_arrow_down</span>
</div>
</section>
<!-- Features / Stats Section -->
<section class="py-20 px-4 bg-background-light dark:bg-background-dark">
<div class="max-w-6xl mx-auto">
<div class="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
<div class="flex flex-col gap-6">
<h2 class="text-4xl md:text-5xl font-bold text-slate-900 dark:text-white leading-tight">
                        Grandeur in <span class="text-primary italic font-serif">Every Detail</span>
</h2>
<p class="text-slate-600 dark:text-white/70 text-lg font-body leading-relaxed">
                        Our large wedding packages are designed for scale. Whether you are hosting a royal banquet or a celebrity gala, we ensure every corner of the venue speaks the language of opulence.
                    </p>
<div class="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-6">
<!-- Stat Card 1 -->
<div class="p-6 rounded-xl border border-slate-200 dark:border-surface-dark bg-white dark:bg-surface-dark shadow-sm hover:shadow-md transition-shadow">
<span class="material-symbols-outlined text-primary text-3xl mb-4">groups</span>
<h3 class="text-xl font-bold text-slate-900 dark:text-white mb-1">1500+ Capacity</h3>
<p class="text-sm text-slate-500 dark:text-[#c99296]">Spacious seating for extensive guest lists.</p>
</div>
<!-- Stat Card 2 -->
<div class="p-6 rounded-xl border border-slate-200 dark:border-surface-dark bg-white dark:bg-surface-dark shadow-sm hover:shadow-md transition-shadow">
<span class="material-symbols-outlined text-primary text-3xl mb-4">castle</span>
<h3 class="text-xl font-bold text-slate-900 dark:text-white mb-1">5 Grand Halls</h3>
<p class="text-sm text-slate-500 dark:text-[#c99296]">High ceilings, panoramic views, and crystal decor.</p>
</div>
<!-- Stat Card 3 -->
<div class="p-6 rounded-xl border border-slate-200 dark:border-surface-dark bg-white dark:bg-surface-dark shadow-sm hover:shadow-md transition-shadow">
<span class="material-symbols-outlined text-primary text-3xl mb-4">restaurant_menu</span>
<h3 class="text-xl font-bold text-slate-900 dark:text-white mb-1">Banquet Service</h3>
<p class="text-sm text-slate-500 dark:text-[#c99296]">Synchronized 5-course service for 100+ tables.</p>
</div>
<!-- Stat Card 4 -->
<div class="p-6 rounded-xl border border-slate-200 dark:border-surface-dark bg-white dark:bg-surface-dark shadow-sm hover:shadow-md transition-shadow">
<span class="material-symbols-outlined text-primary text-3xl mb-4">auto_awesome</span>
<h3 class="text-xl font-bold text-slate-900 dark:text-white mb-1">Premium AV</h3>
<p class="text-sm text-slate-500 dark:text-[#c99296]">Concert-grade sound &amp; lighting systems.</p>
</div>
</div>
</div>
<div class="relative h-[600px] w-full rounded-2xl overflow-hidden group">
<div class="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-105" data-alt="Vertical shot of a luxurious wedding table setting with tall floral centerpieces" style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuCfBGiTHCBZrvL5TTY4ov2dBkgSSrav5wcj9W-36I6XMVvd3PyNDwxIvutoH-h3ieSpWZ1asHjni1i4j8wny1ch_NJF8WIQsTCGDEZkETYlYUnwgXQw2juNKwL8xHl32iZraRkOeAY4h8lcZCRxtUVvr0jM8h1YIAt-YSS5KgaSmKMsNFH_nEG3_qIVOk8KOrE4he2gMXgHkIWzKcqDFTjMd6C-7dL0VM1YC7hYuCzl34Q_EwT_gBwwhvBfIkNUsBYKYGnjZK2Wans");'>
</div>
<div class="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
<div class="absolute bottom-8 left-8 text-white">
<p class="font-bold text-lg mb-1">The Royal Ballroom</p>
<div class="flex items-center gap-1 text-white/80 text-sm">
<span class="material-symbols-outlined text-base">location_on</span>
<span>Main Wing, Floor 1</span>
</div>
</div>
</div>
</div>
</div>
</section>
<!-- Gallery Grid -->
<section class="py-10 bg-white dark:bg-[#1a0d0e]">
<div class="max-w-[1280px] mx-auto px-4 sm:px-10">
<h2 class="text-3xl md:text-4xl font-bold text-center text-slate-900 dark:text-white mb-12">Visualizing Perfection</h2>
<div class="grid grid-cols-1 md:grid-cols-3 gap-4 auto-rows-[300px]">
<!-- Large item spans 2 columns -->
<div class="md:col-span-2 relative group overflow-hidden rounded-xl">
<div class="absolute inset-0 bg-cover bg-center transition-transform duration-500 group-hover:scale-110" data-alt="Wide angle shot of a massive wedding reception hall filled with guests" style='background-image: linear-gradient(to top, rgba(0,0,0,0.6), transparent), url("https://lh3.googleusercontent.com/aida-public/AB6AXuAtJqHJqzIznfVTngLFJiXVKlUD9xicF3M91f6HrOolg09PF09Yhdx5Z3m5qLPf-Q8rBJioSwM9QPJW3vf0Vx8119VuFORKaNCh00DD4xlt9EeR45bKLVqpZSKG9Edhoq2L_Sz3eYt_-5Ca-nLkZvwVmuQE2bkHN2R-d5xyva_nI455hkOScKFI04n6v5-5wPUSWzi2kfVONq0_4PvB4OzE9QqXQcFq9MIoMgPNEz3BQhouIQNwP_dwurY1i6hsZL0r4ribRCWOOfg");'>
</div>
<div class="absolute bottom-0 left-0 p-6">
<h3 class="text-white text-xl font-bold">Grand Foyer Reception</h3>
</div>
</div>
<!-- Standard Item -->
<div class="relative group overflow-hidden rounded-xl">
<div class="absolute inset-0 bg-cover bg-center transition-transform duration-500 group-hover:scale-110" data-alt="Close up of luxury gold cutlery and crystal glasses" style='background-image: linear-gradient(to top, rgba(0,0,0,0.6), transparent), url("https://lh3.googleusercontent.com/aida-public/AB6AXuBY0fN0hRDT75oFcCbZYum002D7IEvV3KcXFXqTxtzJ9FGTQaJk5HR-kDd58yfJ8XJ647jR4suY-nZfndhtG389jTcz1tX71AHD00ARRYqkgzWqWudzOrbNRRtSioFaagZmpaWT5PUVdjgbZprfl52MPmb16alBr_zUXbXOpQjY3J4Dwg1tpVwyY4nvG12fqMVUoCMKMpoBs1Y-Eo070KA32Vp1AsAmuQO_4fdwgpkGfNmekAmgBVNA4FPJIEhaWJIDSNZNl2y5voE");'>
</div>
<div class="absolute bottom-0 left-0 p-6">
<h3 class="text-white text-xl font-bold">Exquisite Dining</h3>
</div>
</div>
<!-- Standard Item -->
<div class="relative group overflow-hidden rounded-xl">
<div class="absolute inset-0 bg-cover bg-center transition-transform duration-500 group-hover:scale-110" data-alt="Outdoor garden wedding setup at night with fairy lights" style='background-image: linear-gradient(to top, rgba(0,0,0,0.6), transparent), url("https://lh3.googleusercontent.com/aida-public/AB6AXuBTu85pc1nuRzqTK5cNBmYI4jtY3OZxUBPrJ344RaJmJoFGVM3Fim-bfINkoBY0B2iODy7Fv1iCTuQQ584x7eDIyFjeS0oIsro4Y8oOQopg7dR4lcoUhrBCmhZx4TbCdYB72LD3efsmv-xC9GVYuz-fl1JzVkucdBADV7TJoANyZkMotedLMUJNQjQe-kkwvVrFZlfJuHC1N9BLCPetDxq9ewrX0TMDbmsiC-ol0T5BGRrq1EcHN3SCd_bv0KOunzv_gE5UM4HWRfo");'>
</div>
<div class="absolute bottom-0 left-0 p-6">
<h3 class="text-white text-xl font-bold">Garden Terrace</h3>
</div>
</div>
<!-- Large item spans 2 columns -->
<div class="md:col-span-2 relative group overflow-hidden rounded-xl">
<div class="absolute inset-0 bg-cover bg-center transition-transform duration-500 group-hover:scale-110" data-alt="Couple dancing in the middle of a large ballroom floor" style='background-image: linear-gradient(to top, rgba(0,0,0,0.6), transparent), url("https://lh3.googleusercontent.com/aida-public/AB6AXuDs98fG1oAqrMjy58eJw_caRs3S00mL0jstQLvFEe9jo9BYXJVJh6BH5pOp32dbqcnAbWIk8JToGblirKgRP3E91_jWesZ0UCEBZyODzi_BZVy2dikN2g8H_tIE7ljORQ3YCluskzlWaBeXnahbODQH1b_W5JIHc5GLop0FairYeGNYURinZO-zLzQoCEI1WnYBrtcDxXZ2AZeZrXk9O_teEgIbC5Ykwx2C4UfB81pJZipbLUeWF524ff79mAEZ2BeB9_y3-lmD2NM");'>
</div>
<div class="absolute bottom-0 left-0 p-6">
<h3 class="text-white text-xl font-bold">First Dance Moments</h3>
</div>
</div>
</div>
</div>
</section>
<!-- Packages & Pricing -->
<section class="py-24 px-4 bg-background-light dark:bg-background-dark">
<div class="max-w-7xl mx-auto">
<div class="text-center mb-16">
<span class="text-primary font-bold tracking-widest uppercase text-sm mb-2 block">Our Offerings</span>
<h2 class="text-3xl md:text-5xl font-bold text-slate-900 dark:text-white">Exclusive Wedding Packages</h2>
<p class="text-slate-600 dark:text-white/60 mt-4 max-w-2xl mx-auto">Tailored for events with 500+ guests. Prices are indicative and may vary based on seasonal demands.</p>
</div>
<div class="grid grid-cols-1 md:grid-cols-3 gap-8">
<!-- Silver Package -->
<div class="relative flex flex-col p-8 rounded-2xl bg-white dark:bg-surface-dark border border-slate-200 dark:border-border-dark hover:border-primary/50 transition-colors">
<div class="mb-6">
<h3 class="text-2xl font-bold text-slate-900 dark:text-white mb-2">Gold Collection</h3>
<p class="text-sm text-slate-500 dark:text-white/60">Perfect for elegant receptions.</p>
</div>
<div class="mb-8">
<span class="text-4xl font-bold text-slate-900 dark:text-white">$120</span>
<span class="text-slate-500 dark:text-white/60">/ guest</span>
</div>
<ul class="flex flex-col gap-4 mb-8 flex-1">
<li class="flex items-start gap-3 text-slate-700 dark:text-white/80 text-sm">
<span class="material-symbols-outlined text-primary text-lg">check_circle</span>
<span>Grand Foyer Access</span>
</li>
<li class="flex items-start gap-3 text-slate-700 dark:text-white/80 text-sm">
<span class="material-symbols-outlined text-primary text-lg">check_circle</span>
<span>4-Course Plated Dinner</span>
</li>
<li class="flex items-start gap-3 text-slate-700 dark:text-white/80 text-sm">
<span class="material-symbols-outlined text-primary text-lg">check_circle</span>
<span>Standard Bar Package (4 Hours)</span>
</li>
<li class="flex items-start gap-3 text-slate-700 dark:text-white/80 text-sm">
<span class="material-symbols-outlined text-primary text-lg">check_circle</span>
<span>Basic Audio &amp; Lighting</span>
</li>
</ul>
<button class="w-full py-3 rounded-lg border border-slate-300 dark:border-white/20 text-slate-900 dark:text-white font-bold hover:bg-slate-50 dark:hover:bg-white/5 transition-colors">
                        Request Quote
                    </button>
</div>
<!-- Platinum Package (Featured) -->
<div class="relative flex flex-col p-8 rounded-2xl bg-white dark:bg-surface-dark border-2 border-primary shadow-xl scale-105 z-10">
<div class="absolute top-0 right-0 bg-primary text-white text-xs font-bold px-3 py-1 rounded-bl-lg rounded-tr-lg">POPULAR</div>
<div class="mb-6">
<h3 class="text-2xl font-bold text-slate-900 dark:text-white mb-2">Platinum Luxury</h3>
<p class="text-sm text-slate-500 dark:text-white/60">The ultimate experience for large parties.</p>
</div>
<div class="mb-8">
<span class="text-4xl font-bold text-slate-900 dark:text-white">$185</span>
<span class="text-slate-500 dark:text-white/60">/ guest</span>
</div>
<ul class="flex flex-col gap-4 mb-8 flex-1">
<li class="flex items-start gap-3 text-slate-700 dark:text-white/80 text-sm">
<span class="material-symbols-outlined text-primary text-lg">check_circle</span>
<span>Ballroom &amp; Terrace Exclusive Use</span>
</li>
<li class="flex items-start gap-3 text-slate-700 dark:text-white/80 text-sm">
<span class="material-symbols-outlined text-primary text-lg">check_circle</span>
<span>7-Course Degustation Menu</span>
</li>
<li class="flex items-start gap-3 text-slate-700 dark:text-white/80 text-sm">
<span class="material-symbols-outlined text-primary text-lg">check_circle</span>
<span>Premium Open Bar (6 Hours)</span>
</li>
<li class="flex items-start gap-3 text-slate-700 dark:text-white/80 text-sm">
<span class="material-symbols-outlined text-primary text-lg">check_circle</span>
<span>Full Floral Decor &amp; Centerpieces</span>
</li>
<li class="flex items-start gap-3 text-slate-700 dark:text-white/80 text-sm">
<span class="material-symbols-outlined text-primary text-lg">check_circle</span>
<span>Live Band Stage Setup</span>
</li>
</ul>
<button class="w-full py-3 rounded-lg bg-primary text-white font-bold hover:bg-red-700 transition-colors shadow-lg shadow-red-900/20">
                        Choose Platinum
                    </button>
</div>
<!-- Diamond Package -->
<div class="relative flex flex-col p-8 rounded-2xl bg-white dark:bg-surface-dark border border-slate-200 dark:border-border-dark hover:border-primary/50 transition-colors">
<div class="mb-6">
<h3 class="text-2xl font-bold text-slate-900 dark:text-white mb-2">Imperial Diamond</h3>
<p class="text-sm text-slate-500 dark:text-white/60">Royalty-grade service and detail.</p>
</div>
<div class="mb-8">
<span class="text-4xl font-bold text-slate-900 dark:text-white">$250+</span>
<span class="text-slate-500 dark:text-white/60">/ guest</span>
</div>
<ul class="flex flex-col gap-4 mb-8 flex-1">
<li class="flex items-start gap-3 text-slate-700 dark:text-white/80 text-sm">
<span class="material-symbols-outlined text-primary text-lg">check_circle</span>
<span>Entire Estate Buyout</span>
</li>
<li class="flex items-start gap-3 text-slate-700 dark:text-white/80 text-sm">
<span class="material-symbols-outlined text-primary text-lg">check_circle</span>
<span>Michelin-Star Guest Chef</span>
</li>
<li class="flex items-start gap-3 text-slate-700 dark:text-white/80 text-sm">
<span class="material-symbols-outlined text-primary text-lg">check_circle</span>
<span>Top Shelf Reserve Spirits</span>
</li>
<li class="flex items-start gap-3 text-slate-700 dark:text-white/80 text-sm">
<span class="material-symbols-outlined text-primary text-lg">check_circle</span>
<span>Fireworks Display</span>
</li>
</ul>
<button class="w-full py-3 rounded-lg border border-slate-300 dark:border-white/20 text-slate-900 dark:text-white font-bold hover:bg-slate-50 dark:hover:bg-white/5 transition-colors">
                        Inquire Price
                    </button>
</div>
</div>
</div>
</section>
<!-- Testimonial Section -->
<section class="py-20 relative overflow-hidden bg-slate-900">
<div class="absolute inset-0 opacity-20 bg-cover bg-center grayscale" data-alt="Abstract blurry wedding reception lights" style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuCJPIxG_tU5-ldHh8tVOivpEJFXASh8d8QWnIWkmBfzA2YblCnL8Y50IOTRYFh50q4Lzx4mx4KCSldtaMvInMqQE9fTJqdWKku0nwwdLQtuOWkDJTQ4-cg-LxkpG62fLOisiLNCMS3844QR5yr-3lY_3HB4aDYgHoFavMe_R230tjeykvpoloqBeTOMqNt_EAJe1Dw2uKhYLGf3BIzc1LG4pnwrfmyzNJOdYpmgMHUAo2KV7LggbcbFpi_6HDigsqQcGhVb47vBIBU");'>
</div>
<div class="relative max-w-4xl mx-auto px-6 text-center">
<span class="material-symbols-outlined text-primary text-5xl mb-6 opacity-80">format_quote</span>
<p class="text-2xl md:text-4xl font-serif text-white italic leading-relaxed mb-8">
                "We had 800 guests, and LUX Weddings made it feel intimate. The service was impeccable, and the ballroom looked like something out of a fairy tale. Truly a night we will never forget."
            </p>
<div class="flex flex-col items-center">
<div class="size-16 rounded-full bg-cover bg-center border-2 border-primary mb-3" data-alt="Profile picture of a happy bride and groom" style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuCjZ40Y4ixJuQE9VVhusKjH4RkQL5tI1b2R4E-IBio1qeJIpExKJlTqUuEvlfLKu7_3KYJN5CRF9p0GfrfYYXcSct-GinEROxFK7vb5vOjTAZfDPOo7E2AVFe0Sr5EfJ4yo3yRcwbfVoQ1AjxuAuDs65gkDa0SaOpwUJY259jYiIBkBv21bxYge12c29k5zWJeUnclK-wnuiwhf5kW4jj9oqLxHJjd4Q-grzaBjtsTM9a7FU0vfyd9042iQ8G3-FMkcuUD_FP-zOKU");'>
</div>
<h4 class="text-white font-bold text-lg">Sarah &amp; James</h4>
<p class="text-white/60 text-sm">Married October 2023</p>
</div>
</div>
</section>
<!-- CTA / Contact Section -->
<section class="py-24 px-4 bg-background-light dark:bg-background-dark border-t border-slate-200 dark:border-border-dark">
<div class="max-w-[1280px] mx-auto bg-white dark:bg-surface-dark rounded-3xl overflow-hidden shadow-2xl flex flex-col md:flex-row">
<div class="md:w-1/2 p-10 md:p-16 flex flex-col justify-center">
<h2 class="text-3xl md:text-4xl font-bold text-slate-900 dark:text-white mb-4">Let's Plan Your Day</h2>
<p class="text-slate-600 dark:text-white/70 mb-8">
                    Ready to bring your vision to life? Fill out the form below to receive a personalized quote or schedule a tour of our magnificent venues.
                </p>
<form class="space-y-4">
<div class="grid grid-cols-2 gap-4">
<div class="flex flex-col gap-1">
<label class="text-xs font-bold text-slate-500 dark:text-white/60 uppercase">First Name</label>
<input class="w-full bg-background-light dark:bg-background-dark border border-slate-300 dark:border-border-dark rounded-lg px-4 py-3 text-slate-900 dark:text-white focus:ring-2 focus:ring-primary focus:outline-none" placeholder="Jane" type="text"/>
</div>
<div class="flex flex-col gap-1">
<label class="text-xs font-bold text-slate-500 dark:text-white/60 uppercase">Last Name</label>
<input class="w-full bg-background-light dark:bg-background-dark border border-slate-300 dark:border-border-dark rounded-lg px-4 py-3 text-slate-900 dark:text-white focus:ring-2 focus:ring-primary focus:outline-none" placeholder="Doe" type="text"/>
</div>
</div>
<div class="flex flex-col gap-1">
<label class="text-xs font-bold text-slate-500 dark:text-white/60 uppercase">Email Address</label>
<input class="w-full bg-background-light dark:bg-background-dark border border-slate-300 dark:border-border-dark rounded-lg px-4 py-3 text-slate-900 dark:text-white focus:ring-2 focus:ring-primary focus:outline-none" placeholder="jane@example.com" type="email"/>
</div>
<div class="flex flex-col gap-1">
<label class="text-xs font-bold text-slate-500 dark:text-white/60 uppercase">Estimated Guests</label>
<select class="w-full bg-background-light dark:bg-background-dark border border-slate-300 dark:border-border-dark rounded-lg px-4 py-3 text-slate-900 dark:text-white focus:ring-2 focus:ring-primary focus:outline-none">
<option>500 - 700</option>
<option>700 - 1000</option>
<option>1000 - 1500</option>
<option>1500+</option>
</select>
</div>
<button class="w-full bg-primary hover:bg-red-700 text-white font-bold text-lg py-4 rounded-lg mt-4 transition-colors" type="button">
                        Request Availability
                    </button>
</form>
</div>
<div class="md:w-1/2 bg-cover bg-center min-h-[400px]" data-alt="Elegant table setting with name cards and candles" style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuAtvaLfpdwFnCfFQxOnsO1QuGWqk-hHESA6KudwmOmgBJYOUB_GyLh8Q4FH5uuInU-Z8Xy7ZxpuKf6UkDMndr-0JFeiUNuUj9g1fTRWqTww9M6m2SMOYMjau2BcAHh02krTK3ya9v8L76Rl7kWSxNe1OzyVeH4ezzVRjZEyFuXOiV4V4dtVYzMQImbqgCoOMCa18idPzrTRDFiILtCb43__8R2Qgp2fFlVAplYw9Q9gNw_jO2gvbsFUBjHH1Q7llt2JkdmwUR_8Vw8");'>
</div>
</div>
</section>
<!-- Footer -->
<footer class="bg-background-dark border-t border-border-dark pt-16 pb-8 px-4">
<div class="max-w-[1280px] mx-auto">
<div class="grid grid-cols-1 md:grid-cols-4 gap-10 mb-12">
<div class="col-span-1 md:col-span-1">
<div class="flex items-center gap-2 text-white mb-6">
<span class="material-symbols-outlined text-3xl text-primary">diamond</span>
<span class="text-xl font-bold">LUX WEDDINGS</span>
</div>
<p class="text-white/50 text-sm leading-relaxed">
                        Creating unforgettable memories for the grandest celebrations. Where luxury meets scale.
                    </p>
</div>
<div>
<h4 class="text-white font-bold mb-6">Quick Links</h4>
<ul class="space-y-3">
<li><a class="text-white/60 hover:text-primary text-sm transition-colors" href="#">Our Venues</a></li>
<li><a class="text-white/60 hover:text-primary text-sm transition-colors" href="#">Wedding Packages</a></li>
<li><a class="text-white/60 hover:text-primary text-sm transition-colors" href="#">Catering Menu</a></li>
<li><a class="text-white/60 hover:text-primary text-sm transition-colors" href="#">Photo Gallery</a></li>
</ul>
</div>
<div>
<h4 class="text-white font-bold mb-6">Contact Us</h4>
<ul class="space-y-3">
<li class="flex items-center gap-2 text-white/60 text-sm">
<span class="material-symbols-outlined text-primary text-base">call</span>
                            +1 (555) 123-4567
                        </li>
<li class="flex items-center gap-2 text-white/60 text-sm">
<span class="material-symbols-outlined text-primary text-base">mail</span>
                            events@luxweddings.com
                        </li>
<li class="flex items-center gap-2 text-white/60 text-sm">
<span class="material-symbols-outlined text-primary text-base">location_on</span>
                            123 Luxury Blvd, Beverly Hills, CA
                        </li>
</ul>
</div>
<div>
<h4 class="text-white font-bold mb-6">Follow Us</h4>
<div class="flex gap-4">
<a class="size-10 rounded-full bg-white/5 flex items-center justify-center text-white hover:bg-primary transition-colors" href="#">
<span class="font-bold text-xs">FB</span>
</a>
<a class="size-10 rounded-full bg-white/5 flex items-center justify-center text-white hover:bg-primary transition-colors" href="#">
<span class="font-bold text-xs">IG</span>
</a>
<a class="size-10 rounded-full bg-white/5 flex items-center justify-center text-white hover:bg-primary transition-colors" href="#">
<span class="font-bold text-xs">TW</span>
</a>
</div>
</div>
</div>
<div class="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-white/40">
<p>© 2024 Lux Weddings. All rights reserved.</p>
<div class="flex gap-6">
<a class="hover:text-white transition-colors" href="#">Privacy Policy</a>
<a class="hover:text-white transition-colors" href="#">Terms of Service</a>
</div>
</div>
</div>
</footer>
<!-- Floating Action Button -->
<a class="fixed bottom-6 right-6 z-50 bg-green-600 hover:bg-green-500 text-white rounded-full p-4 shadow-lg hover:scale-110 transition-transform flex items-center gap-2 group" href="#">
<span class="material-symbols-outlined">chat</span>
<span class="max-w-0 overflow-hidden group-hover:max-w-xs transition-all duration-300 whitespace-nowrap font-bold">Chat on WhatsApp</span>
</a>
</body></html>