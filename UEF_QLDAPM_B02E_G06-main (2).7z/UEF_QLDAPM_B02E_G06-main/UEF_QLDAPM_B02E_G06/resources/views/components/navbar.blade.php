<aside class="w-80 bg-sidebar-light dark:bg-sidebar-dark border-r border-gray-200 dark:border-gray-700 flex flex-col shadow-xl z-20 relative">
    <div class="h-16 flex items-center justify-between px-5 border-b border-gray-100 dark:border-gray-800 shrink-0">
        <div class="flex items-center gap-2">
            <div class="w-8 h-8 bg-primary rounded-lg flex items-center justify-center shadow-lg shadow-blue-500/30">
                <span class="material-icons-outlined text-white text-lg">category</span>
            </div>
            <span class="text-sm font-bold tracking-tight text-gray-800 dark:text-white">Selection</span>
        </div>
        <div class="flex space-x-1">
            <button class="p-1.5 rounded-md hover:bg-gray-50 dark:hover:bg-gray-800 text-gray-400 hover:text-primary transition-colors">
                <span class="material-icons-outlined text-lg">search</span>
            </button>
            <button class="p-1.5 rounded-md hover:bg-gray-50 dark:hover:bg-gray-800 text-gray-400 hover:text-primary transition-colors">
                <span class="material-icons-outlined text-lg">add</span>
            </button>
        </div>
    </div>

    <div class="flex-1 overflow-y-auto py-4 px-3 space-y-6 custom-scrollbar">
        
        <div>
            <div class="px-2 mb-2 text-[11px] font-bold text-gray-400 dark:text-gray-500 uppercase tracking-widest flex items-center gap-1">
                <span class="material-icons-outlined text-xs">home_work</span> Accommodations
            </div>
            <div class="space-y-2">
                <a href="/chi-tiet-villa" class="w-full flex items-center group p-2 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-800 border border-transparent hover:border-gray-100 dark:hover:border-gray-700 transition-all duration-200">
                    <div class="w-12 h-12 rounded-lg bg-gray-200 dark:bg-gray-700 mr-3 overflow-hidden shadow-sm relative group-hover:shadow-md transition-shadow">
                        <img alt="Villa" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" src="https://images.unsplash.com/photo-1564013799919-ab600027ffc6?auto=format&fit=crop&w=100&q=80"/>
                    </div>
                    <div class="flex-1 text-left min-w-0">
                        <p class="text-sm font-semibold text-gray-700 dark:text-gray-200 group-hover:text-primary transition-colors truncate">Khu Villa desktop</p>
                        <p class="text-[10px] text-gray-400 dark:text-gray-500 truncate">Luxury & Private Pool</p>
                    </div>
                </a>

               <a href="/chi-tiet-rose-house" class="w-full flex items-center group p-2 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-800 border border-transparent hover:border-gray-100 dark:hover:border-gray-700 transition-all duration-200">
                    <div class="w-12 h-12 rounded-lg bg-gray-200 dark:bg-gray-700 mr-3 overflow-hidden shadow-sm relative group-hover:shadow-md transition-shadow">
                        <img alt="Rose House" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" src="https://images.unsplash.com/photo-1518780664697-55e3ad937233?auto=format&fit=crop&w=100&q=80"/>
                    </div>
                    <div class="flex-1 text-left min-w-0">
                        <p class="text-sm font-semibold text-gray-700 dark:text-gray-200 group-hover:text-primary transition-colors truncate">Khu Rose house</p>
                        <p class="text-[10px] text-gray-400 dark:text-gray-500 truncate">Garden View</p>
                    </div>
                </a>

                <a href="/chi-tiet-wooden-house" class="w-full flex items-center group p-2 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-800 border border-transparent hover:border-gray-100 dark:hover:border-gray-700 transition-all duration-200">
                    <div class="w-12 h-12 rounded-lg bg-gray-200 dark:bg-gray-700 mr-3 overflow-hidden shadow-sm relative group-hover:shadow-md transition-shadow">
                        <img alt="Wooden House" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" src="https://images.unsplash.com/photo-1449844908441-8829872d2607?auto=format&fit=crop&w=100&q=80"/>
                    </div>
                    <div class="flex-1 text-left min-w-0">
                        <p class="text-sm font-semibold text-gray-700 dark:text-gray-200 group-hover:text-primary transition-colors truncate">Khu wooden house</p>
                        <p class="text-[10px] text-gray-400 dark:text-gray-500 truncate">Forest Cabin</p>
                    </div>
                </a>
            </div>
        </div>

        <div>
            <div class="px-2 mb-2 text-[11px] font-bold text-gray-400 dark:text-gray-500 uppercase tracking-widest flex items-center gap-1">
                <span class="material-icons-outlined text-xs">event</span> Events
            </div>
            <div class="space-y-2">
                <a href="/chi-tiet-tiec-cuoi-nho" class="w-full flex items-center group p-2 rounded-xl bg-primary/5 dark:bg-primary/20 border border-primary/20 dark:border-primary/30 relative overflow-hidden transition-all duration-200 shadow-sm">
                    <div class="absolute inset-y-0 left-0 w-1 bg-primary rounded-l-md"></div>
                    <div class="w-12 h-12 rounded-lg bg-gray-200 dark:bg-gray-700 mr-3 overflow-hidden shadow-sm relative ring-2 ring-white dark:ring-gray-800">
                        <img alt="Wedding" class="w-full h-full object-cover" src="https://images.unsplash.com/photo-1511795409834-ef04bbd61622?auto=format&fit=crop&w=100&q=80"/>
                    </div>
                    <div class="flex-1 text-left min-w-0 z-10">
                        <p class="text-sm font-bold text-primary dark:text-white truncate">Tiệc cưới nhỏ</p>
                        <p class="text-[10px] text-primary/70 dark:text-gray-300 truncate font-medium">Currently Selected</p>
                    </div>
                    <div class="bg-white dark:bg-gray-800 p-1.5 rounded-full shadow-sm text-primary z-10">
                        <span class="material-icons-outlined text-sm block">edit</span>
                    </div>
                </a >

                <a href="/chi-tiet-tiec-cuoi-lon" class="w-full flex items-center group p-2 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-800 border border-transparent hover:border-gray-100 dark:hover:border-gray-700 transition-all duration-200">
                    <div class="w-12 h-12 rounded-lg bg-gray-200 dark:bg-gray-700 mr-3 overflow-hidden shadow-sm relative group-hover:shadow-md transition-shadow">
                        <img alt="Event" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" src="https://images.unsplash.com/photo-1511795409834-ef04bbd61622?auto=format&fit=crop&w=100&q=80"/>
                    </div>
                    <div class="flex-1 text-left min-w-0">
                        <p class="text-sm font-semibold text-gray-700 dark:text-gray-200 group-hover:text-primary transition-colors truncate">Tiệc cưới lớn</p>
                        <p class="text-[10px] text-gray-400 dark:text-gray-500 truncate">Outdoor Setup</p>
                    </div>
                </a>
            </div>
        </div>

        <div>
            <div class="px-2 mb-2 text-[11px] font-bold text-gray-400 dark:text-gray-500 uppercase tracking-widest flex items-center gap-1">
                <span class="material-icons-outlined text-xs">bed</span> Rooms
            </div>
            <div class="space-y-2">
                <a href="/chi-tiet-family-room" class="w-full flex items-center group p-2 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-800 border border-transparent hover:border-gray-100 dark:hover:border-gray-700 transition-all duration-200">
                    <div class="w-12 h-12 rounded-lg bg-gray-200 dark:bg-gray-700 mr-3 overflow-hidden shadow-sm relative group-hover:shadow-md transition-shadow">
                        <img alt="Family Room" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" src="https://images.unsplash.com/photo-1578683010236-d716f9a3f461?auto=format&fit=crop&w=100&q=80"/>
                    </div>
                    <div class="flex-1 text-left min-w-0">
                        <p class="text-sm font-semibold text-gray-700 dark:text-gray-200 group-hover:text-primary transition-colors truncate">Family room desktop</p>
                        <p class="text-[10px] text-gray-400 dark:text-gray-500 truncate">2 Queen Beds</p>
                    </div>
                </a>

               <a href="/chi-tiet-deluxe-room" class="w-full flex items-center group p-2 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-800 border border-transparent hover:border-gray-100 dark:hover:border-gray-700 transition-all duration-200">
                    <div class="w-12 h-12 rounded-lg bg-gray-200 dark:bg-gray-700 mr-3 overflow-hidden shadow-sm relative group-hover:shadow-md transition-shadow">
                        <img alt="Deluxe Room" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" src="https://images.unsplash.com/photo-1631049307264-da0ec9d70304?auto=format&fit=crop&w=100&q=80"/>
                    </div>
                    <div class="flex-1 text-left min-w-0">
                        <p class="text-sm font-semibold text-gray-700 dark:text-gray-200 group-hover:text-primary transition-colors truncate">Deluxe room desktop</p>
                        <p class="text-[10px] text-gray-400 dark:text-gray-500 truncate">Ocean View</p>
                    </div>
                </a>

                <a href="/chi-tiet-red-rose-house" class="w-full flex items-center group p-2 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-800 border border-transparent hover:border-gray-100 dark:hover:border-gray-700 transition-all duration-200">
                    <div class="w-12 h-12 rounded-lg bg-gray-200 dark:bg-gray-700 mr-3 overflow-hidden shadow-sm relative group-hover:shadow-md transition-shadow">
                        <img alt="Red Rose" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" src="https://images.unsplash.com/photo-1566665797739-1674de7a421a?auto=format&fit=crop&w=100&q=80"/>
                    </div>
                    <div class="flex-1 text-left min-w-0">
                        <p class="text-sm font-semibold text-gray-700 dark:text-gray-200 group-hover:text-primary transition-colors truncate">Red rose house desktop</p>
                        <p class="text-[10px] text-gray-400 dark:text-gray-500 truncate">Romantic Suite</p>
                    </div>
                </a>
            </div>
        </div>

    </div>
    
    <div class="p-4 border-t border-gray-200 dark:border-gray-700 bg-gray-50/50 dark:bg-[#1a1a1a]">
        <button class="w-full flex items-center p-2.5 rounded-xl hover:bg-white dark:hover:bg-gray-800 transition-all shadow-sm hover:shadow-md border border-gray-100 dark:border-gray-700 group">
             <div class="w-9 h-9 rounded-full bg-gradient-to-tr from-primary to-blue-600 flex items-center justify-center text-white text-xs font-bold shadow-md group-hover:scale-105 transition-transform">
                AD
            </div>
             <div class="ml-3 text-left">
                 <p class="text-xs font-bold text-gray-700 dark:text-gray-200 group-hover:text-primary transition-colors">Admin User</p>
                 <p class="text-[10px] text-gray-500 dark:text-gray-400">View Settings</p>
             </div>
             <span class="material-icons-outlined text-gray-400 ml-auto text-lg group-hover:text-primary transition-colors">settings</span>
        </button>
    </div>
</aside>