<!DOCTYPE html>

<html class="light" lang="en"><head>
<meta charset="utf-8"/>
<meta content="width=device-width, initial-scale=1.0" name="viewport"/>
<title>Deluxe Family Suite - StayCation</title>
<script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&amp;display=swap" rel="stylesheet"/>
<link href="https://fonts.googleapis.com" rel="preconnect"/>
<link crossorigin="" href="https://fonts.gstatic.com" rel="preconnect"/>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;700;800&amp;display=swap" rel="stylesheet"/>
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&amp;display=swap" rel="stylesheet"/>
<script id="tailwind-config">
        tailwind.config = {
            darkMode: "class",
            theme: {
                extend: {
                    colors: {
                        "primary": "#ec6d13",
                        "background-light": "#f8f7f6",
                        "background-dark": "#221810",
                        "text-main": "#1b130d",
                    },
                    fontFamily: {
                        "display": ["Plus Jakarta Sans", "sans-serif"]
                    },
                    borderRadius: { "DEFAULT": "0.5rem", "lg": "1rem", "xl": "1.5rem", "full": "9999px" },
                },
            },
        }
    </script>
<style>
        body {
            font-family: "Plus Jakarta Sans", sans-serif;
        }
    </style>
</head>
<body class="bg-background-light dark:bg-background-dark text-text-main dark:text-white transition-colors duration-200">
<div class="relative flex min-h-screen w-full flex-col overflow-x-hidden group/design-root">
<!-- Navigation -->
<div class="layout-container flex w-full flex-col border-b border-[#f3ece7] dark:border-white/10 bg-background-light dark:bg-background-dark sticky top-0 z-50">
<div class="w-full flex justify-center">
<div class="flex w-full max-w-[1280px] flex-col">
<header class="flex items-center justify-between whitespace-nowrap px-4 lg:px-10 py-3">
<div class="flex items-center gap-4 text-text-main dark:text-white">
<div class="size-8 text-primary">
<span class="material-symbols-outlined text-[32px]">travel_explore</span>
</div>
<h2 class="text-text-main dark:text-white text-xl font-bold leading-tight tracking-[-0.015em]">StayCation</h2>
</div>
<div class="hidden lg:flex flex-1 justify-end gap-8">
<div class="flex items-center gap-9">
<a class="text-text-main dark:text-gray-300 hover:text-primary dark:hover:text-primary transition-colors text-sm font-medium leading-normal" href="#">Rooms</a>
<a class="text-text-main dark:text-gray-300 hover:text-primary dark:hover:text-primary transition-colors text-sm font-medium leading-normal" href="#">Events</a>
<a class="text-text-main dark:text-gray-300 hover:text-primary dark:hover:text-primary transition-colors text-sm font-medium leading-normal" href="#">Dining</a>
<a class="text-text-main dark:text-gray-300 hover:text-primary dark:hover:text-primary transition-colors text-sm font-medium leading-normal" href="#">Contact</a>
</div>
<div class="flex gap-2">
<button class="flex min-w-[84px] cursor-pointer items-center justify-center overflow-hidden rounded-xl h-10 px-4 bg-primary hover:bg-primary/90 transition-colors text-[#fcfaf8] text-sm font-bold leading-normal tracking-[0.015em]">
<span class="truncate">Sign In</span>
</button>
<button class="flex min-w-[84px] cursor-pointer items-center justify-center overflow-hidden rounded-xl h-10 px-4 bg-[#f3ece7] dark:bg-white/10 hover:bg-[#e7ded6] dark:hover:bg-white/20 transition-colors text-text-main dark:text-white text-sm font-bold leading-normal tracking-[0.015em]">
<span class="truncate">Join Now</span>
</button>
</div>
</div>
<div class="lg:hidden">
<button class="p-2 text-text-main dark:text-white">
<span class="material-symbols-outlined">menu</span>
</button>
</div>
</header>
</div>
</div>
</div>
<!-- Main Content Wrapper -->
<main class="flex-1 w-full flex justify-center py-6 lg:py-10 px-4 sm:px-6">
<div class="w-full max-w-[1280px] grid grid-cols-1 lg:grid-cols-12 gap-8 relative">
<!-- Left Column: Content -->
<div class="lg:col-span-8 flex flex-col gap-6">
<!-- Hero Image Gallery -->
<div class="w-full rounded-2xl overflow-hidden shadow-sm grid grid-cols-1 md:grid-cols-4 gap-2 h-[400px] md:h-[500px]">
<div class="md:col-span-3 md:row-span-2 h-full bg-gray-200 relative group cursor-pointer">
<div class="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-105" data-alt="Spacious bright hotel room with king bed and ocean view" style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuCbKJ7gd96LwPinPyk-C6g9vMKwZ-6o2oCELUi-4ONbyESl361_8zezPiCHmQmlnslUpJteFy7Jpmu_aJbaq717cNusTjLQE_uU484lKFSffPW-Z1SbKm9SHfMCByAq5GupsozasjSr50b3krua9-cXnQGUQCo--L1Ma7REw3TEl_yrfObGEPIINe996Sx3E3hPPzL41pqQj8FugGBh_e6YEllCnAT9W9DaEcuPd6FKM0LvPS2ElkwL4CfVDmKC3FnSgDiPpRobnJk");'>
</div>
<div class="absolute bottom-4 left-4 bg-black/50 backdrop-blur-sm text-white px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider">
                                Main Bedroom
                            </div>
</div>
<div class="hidden md:block h-full bg-gray-200 relative group cursor-pointer">
<div class="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-105" data-alt="Cozy children bunk beds area" style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuA2Ha2gwSwzzthIWqdRszCjkHEihw6tRr_Rrw7nJlqPTw9OqwbCNWpS7SHoIAPOxooNbU5RSdkX85YnGRxbZZyX0O_b3esO2-aYqAf65PMu0cajglcT39gZ8-Auxf68mkMEmD9ZNt1ThmcsTNHT2W208_94hHa0dmgExBMiXp_Y4mqwfJRHj82uLDthlWgG8hEMWeCCWeQhtJkKrUvUaAXocWBTEZwMw2nl3IzM_wxN1kA0NHt07YCEURfYITKvrZC81thSWkWWdCA");'>
</div>
</div>
<div class="hidden md:block h-full bg-gray-200 relative group cursor-pointer">
<div class="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-105" data-alt="Modern bathroom with soaking tub" style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuDq6-H8QNLVsQaUM1YuEuOL1APEwjpyuz35gfJ8Lxr-wfMPVgCM1J8fsqxCJxY_2YqAlbacJoEtnftCoOarAeXmW0KD0YDb6EtIWLDf6r7lfmxIbwsFHzD77RVJhSoYOYw4tuMztAtNwNWUJXw2XlPlfSJHAcTiV6eocAfsOkN4pb-TEyBZRmapvbhQ-TbGhosUw8MplLGdTkDUB5zpfS6YcfbBYNaA_P8mzJU1wDMyD6YS9rV53vgz94ljGe3OvtDfezxm1ZbD0Z4");'>
</div>
<div class="absolute inset-0 bg-black/40 hover:bg-black/30 transition-colors flex items-center justify-center text-white font-bold cursor-pointer">
<span class="flex items-center gap-1"><span class="material-symbols-outlined">grid_view</span> See All Photos</span>
</div>
</div>
</div>
<!-- Title & Basic Info -->
<div class="flex flex-col gap-2 pb-4 border-b border-gray-200 dark:border-white/10">
<div class="flex items-start justify-between">
<div>
<h1 class="text-3xl md:text-4xl font-bold text-text-main dark:text-white tracking-tight">Deluxe Family Suite – Ocean View</h1>
<p class="text-gray-500 dark:text-gray-400 mt-2 text-lg">Santa Monica, California</p>
</div>
<div class="flex flex-col items-end">
<div class="flex items-center gap-1 text-primary">
<span class="material-symbols-outlined text-sm">star</span>
<span class="font-bold text-lg">4.92</span>
<span class="text-gray-400 dark:text-gray-500 text-sm font-medium underline">(128 reviews)</span>
</div>
</div>
</div>
<!-- Quick Tags -->
<div class="flex flex-wrap gap-3 mt-4">
<span class="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-semibold">
<span class="material-symbols-outlined text-[18px]">family_restroom</span> 2 Adults, 2 Kids
                            </span>
<span class="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-gray-100 dark:bg-white/10 text-gray-700 dark:text-gray-300 text-sm font-medium">
<span class="material-symbols-outlined text-[18px]">square_foot</span> 850 sq ft
                            </span>
<span class="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-gray-100 dark:bg-white/10 text-gray-700 dark:text-gray-300 text-sm font-medium">
<span class="material-symbols-outlined text-[18px]">king_bed</span> 1 King Bed
                            </span>
<span class="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-gray-100 dark:bg-white/10 text-gray-700 dark:text-gray-300 text-sm font-medium">
<span class="material-symbols-outlined text-[18px]">single_bed</span> 2 Bunk Beds
                            </span>
</div>
</div>
<!-- Description -->
<div class="py-2">
<h2 class="text-2xl font-bold text-text-main dark:text-white mb-4">A home away from home</h2>
<p class="text-base md:text-lg leading-relaxed text-gray-600 dark:text-gray-300">
                            Experience the ultimate family getaway in our Deluxe Family Suite. Featuring separate sleeping areas for adults and children to ensure privacy and rest for everyone. The spacious living area is perfect for game nights, and a fully equipped kitchenette allows for easy snack preparation. Wake up to the sound of waves, enjoy your morning coffee on the private balcony, and let the kids explore the dedicated play corner.
                        </p>
</div>
<!-- Amenities Grid -->
<div class="py-4 border-t border-gray-200 dark:border-white/10">
<h2 class="text-2xl font-bold text-text-main dark:text-white mb-6">Room Amenities</h2>
<div class="grid grid-cols-2 md:grid-cols-3 gap-y-6 gap-x-4">
<div class="flex items-center gap-3">
<span class="material-symbols-outlined text-primary">wifi</span>
<span class="text-gray-700 dark:text-gray-300">Fast Wifi</span>
</div>
<div class="flex items-center gap-3">
<span class="material-symbols-outlined text-primary">kitchen</span>
<span class="text-gray-700 dark:text-gray-300">Kitchenette</span>
</div>
<div class="flex items-center gap-3">
<span class="material-symbols-outlined text-primary">tv</span>
<span class="text-gray-700 dark:text-gray-300">55" Smart TV</span>
</div>
<div class="flex items-center gap-3">
<span class="material-symbols-outlined text-primary">ac_unit</span>
<span class="text-gray-700 dark:text-gray-300">Climate Control</span>
</div>
<div class="flex items-center gap-3">
<span class="material-symbols-outlined text-primary">bathtub</span>
<span class="text-gray-700 dark:text-gray-300">Soaking Tub</span>
</div>
<div class="flex items-center gap-3">
<span class="material-symbols-outlined text-primary">child_friendly</span>
<span class="text-gray-700 dark:text-gray-300">Kids Play Corner</span>
</div>
<div class="flex items-center gap-3">
<span class="material-symbols-outlined text-primary">local_laundry_service</span>
<span class="text-gray-700 dark:text-gray-300">In-unit Laundry</span>
</div>
<div class="flex items-center gap-3">
<span class="material-symbols-outlined text-primary">crib</span>
<span class="text-gray-700 dark:text-gray-300">Crib Available</span>
</div>
<div class="flex items-center gap-3">
<span class="material-symbols-outlined text-primary">balcony</span>
<span class="text-gray-700 dark:text-gray-300">Ocean View Balcony</span>
</div>
</div>
<button class="mt-6 px-6 py-2.5 rounded-lg border border-gray-300 dark:border-white/20 text-text-main dark:text-white font-semibold hover:bg-gray-50 dark:hover:bg-white/5 transition-colors">
                            Show all 24 amenities
                        </button>
</div>
<!-- Family Features Highlight -->
<div class="py-6 border-t border-gray-200 dark:border-white/10">
<div class="bg-primary/5 dark:bg-primary/10 rounded-2xl p-6 md:p-8 flex flex-col md:flex-row gap-6 items-center">
<div class="flex-1">
<h3 class="text-xl font-bold text-text-main dark:text-white mb-2">Perfect for Families</h3>
<ul class="space-y-3">
<li class="flex items-start gap-2 text-gray-700 dark:text-gray-300">
<span class="material-symbols-outlined text-primary text-xl">check_circle</span>
<span>Kids under 12 eat free at the resort buffet.</span>
</li>
<li class="flex items-start gap-2 text-gray-700 dark:text-gray-300">
<span class="material-symbols-outlined text-primary text-xl">check_circle</span>
<span>Complimentary access to the "Mini Explorers" kids club.</span>
</li>
<li class="flex items-start gap-2 text-gray-700 dark:text-gray-300">
<span class="material-symbols-outlined text-primary text-xl">check_circle</span>
<span>Welcome pack with beach toys and coloring books.</span>
</li>
</ul>
</div>
<div class="w-full md:w-48 h-32 rounded-xl bg-cover bg-center shadow-md" data-alt="Happy kids playing with toys in a bright room" style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuCuDvbVOrEqBE_FIxmv3FW_EV3Eku6FTEXt7qKHW7p6a3uBVXcYeIcvTdPPuopO9AuBbNilXbM7G9UEJbnYRA1_O_tmzHe0EkofKLXxUVIhIVdFFVerfzgRaTfcApvs_5Aa90BNHXoLImZQ_HgvXGTuRfStlyqRTmpSCuGWug7Gg2fjATXx5lD4A2i-SC_Zo960pgzIhVS9OoevxTEyXbvoS4M8OH3vkX3-f7iGSDAEB3JJSg3GUckRrbUaq2EdHfzCRAuOLkEusXo");'>
</div>
</div>
</div>
<!-- Floor Plan Section -->
<div class="py-4 border-t border-gray-200 dark:border-white/10">
<h2 class="text-2xl font-bold text-text-main dark:text-white mb-6">Sleeping Arrangements</h2>
<div class="flex flex-col md:flex-row gap-8">
<div class="flex-1 bg-white dark:bg-white/5 border border-gray-200 dark:border-white/10 rounded-xl p-6 shadow-sm">
<div class="flex items-center gap-4 mb-4">
<span class="material-symbols-outlined text-3xl text-gray-600 dark:text-gray-400">king_bed</span>
<div>
<h4 class="font-bold text-text-main dark:text-white">Master Bedroom</h4>
<p class="text-sm text-gray-500">1 King Bed</p>
</div>
</div>
<p class="text-sm text-gray-600 dark:text-gray-400">Plush memory foam mattress with premium linens, facing the ocean view balcony.</p>
</div>
<div class="flex-1 bg-white dark:bg-white/5 border border-gray-200 dark:border-white/10 rounded-xl p-6 shadow-sm">
<div class="flex items-center gap-4 mb-4">
<span class="material-symbols-outlined text-3xl text-gray-600 dark:text-gray-400">bed</span>
<div>
<h4 class="font-bold text-text-main dark:text-white">Kids Nook</h4>
<p class="text-sm text-gray-500">1 Bunk Bed (Twin/Twin)</p>
</div>
</div>
<p class="text-sm text-gray-600 dark:text-gray-400">Secure and cozy bunk beds with individual reading lights and privacy curtains.</p>
</div>
</div>
</div>
</div>
<!-- Right Column: Sticky Booking Card -->
<div class="lg:col-span-4 relative">
<div class="sticky top-24">
<div class="bg-white dark:bg-[#2a2018] rounded-2xl shadow-[0_8px_30px_rgb(0,0,0,0.08)] dark:shadow-black/40 border border-gray-100 dark:border-white/5 p-6 md:p-8">
<div class="flex justify-between items-end mb-6">
<div>
<span class="text-sm text-gray-500 dark:text-gray-400 line-through">$320</span>
<div class="flex items-baseline gap-1">
<span class="text-3xl font-bold text-text-main dark:text-white">$249</span>
<span class="text-gray-600 dark:text-gray-400">/ night</span>
</div>
</div>
<div class="bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300 px-2 py-1 rounded text-xs font-bold">
                                    -22% OFFER
                                </div>
</div>
<!-- Date Picker Mockup -->
<div class="border border-gray-200 dark:border-white/10 rounded-xl overflow-hidden mb-4">
<div class="grid grid-cols-2 divide-x divide-gray-200 dark:divide-white/10 border-b border-gray-200 dark:border-white/10">
<div class="p-3 hover:bg-gray-50 dark:hover:bg-white/5 cursor-pointer transition-colors">
<label class="block text-[10px] font-bold uppercase tracking-wider text-gray-500">Check-in</label>
<div class="text-sm font-medium text-text-main dark:text-white">Oct 14, 2023</div>
</div>
<div class="p-3 hover:bg-gray-50 dark:hover:bg-white/5 cursor-pointer transition-colors">
<label class="block text-[10px] font-bold uppercase tracking-wider text-gray-500">Check-out</label>
<div class="text-sm font-medium text-text-main dark:text-white">Oct 21, 2023</div>
</div>
</div>
<div class="p-3 hover:bg-gray-50 dark:hover:bg-white/5 cursor-pointer transition-colors flex justify-between items-center">
<div>
<label class="block text-[10px] font-bold uppercase tracking-wider text-gray-500">Guests</label>
<div class="text-sm font-medium text-text-main dark:text-white">2 Adults, 2 Children</div>
</div>
<span class="material-symbols-outlined text-gray-400">expand_more</span>
</div>
</div>
<button class="w-full bg-primary hover:bg-primary/90 text-white font-bold text-lg py-3.5 rounded-xl transition-all shadow-lg shadow-primary/30 mb-4">
                                Check Availability
                            </button>
<div class="flex justify-between text-sm text-gray-600 dark:text-gray-400 mb-6">
<span class="underline cursor-pointer">Price breakdown</span>
<span>Total: $1,743</span>
</div>
<div class="space-y-3 pt-4 border-t border-gray-100 dark:border-white/5">
<div class="flex items-center gap-3 text-sm text-gray-600 dark:text-gray-400">
<span class="material-symbols-outlined text-gray-400">event_available</span>
<span>Free cancellation until Oct 12</span>
</div>
<div class="flex items-center gap-3 text-sm text-gray-600 dark:text-gray-400">
<span class="material-symbols-outlined text-gray-400">diamond</span>
<span>Best Price Guarantee</span>
</div>
</div>
</div>
<!-- Mini Contact Card -->
<div class="mt-6 flex items-center justify-center gap-2 text-primary font-medium cursor-pointer hover:underline">
<span class="material-symbols-outlined">chat</span>
<span>Chat with a concierge</span>
</div>
</div>
</div>
</div>
</main>
<!-- Similar Rooms Section (Bottom) -->
<section class="w-full flex justify-center py-12 bg-gray-50 dark:bg-white/5 border-t border-gray-200 dark:border-white/10">
<div class="w-full max-w-[1280px] px-4 sm:px-6">
<h3 class="text-2xl font-bold text-text-main dark:text-white mb-6">You might also like</h3>
<div class="grid grid-cols-1 md:grid-cols-3 gap-6">
<!-- Card 1 -->
<div class="group cursor-pointer">
<div class="aspect-[4/3] w-full rounded-xl bg-gray-200 overflow-hidden relative mb-3">
<div class="absolute inset-0 bg-cover bg-center transition-transform duration-500 group-hover:scale-105" data-alt="Luxurious suite with private pool deck" style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuBMajQO3x_klBkagwBQmB4SKkBPdFtLRXaW7_dQ6a4xzaIz5Zo4GegGK2jjiSoID0FS64X38_IsBEQwuGOtQFIHqKuKAqGnIP7q7efRBW7bBFdvjREIWfOdM6hpgYDOxwYitwVhD81zrT4yEiwOE-zjXuw7Oan3QrSY99DmBH7CCfZquwrPWWvDxkBsMkQ2KQKPyGiSgNS8UqO-zmr7uG05ukTBeIJ4nMR_sf932qrlyqTpajh5hx3Zr0KBZr15bkWLMYGJG5xp9-U");'>
</div>
<button class="absolute top-3 right-3 p-2 bg-white/80 dark:bg-black/50 backdrop-blur-sm rounded-full hover:bg-white text-gray-700 dark:text-white transition-colors">
<span class="material-symbols-outlined text-[20px]">favorite</span>
</button>
</div>
<div class="flex justify-between items-start">
<div>
<h4 class="font-bold text-text-main dark:text-white group-hover:text-primary transition-colors">Garden Villa Suite</h4>
<p class="text-sm text-gray-500">Sleeps 5 • 1200 sq ft</p>
</div>
<div class="text-right">
<p class="font-bold text-text-main dark:text-white">$310</p>
<p class="text-xs text-gray-500">/ night</p>
</div>
</div>
</div>
<!-- Card 2 -->
<div class="group cursor-pointer">
<div class="aspect-[4/3] w-full rounded-xl bg-gray-200 overflow-hidden relative mb-3">
<div class="absolute inset-0 bg-cover bg-center transition-transform duration-500 group-hover:scale-105" data-alt="Modern double room with connecting door" style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuB7yhJRWxcCdbUIhU_tXNG8xurce0xT25N5ZGsELf2KKgL9TyfIs4ItBiGFrTiLg-nOtGELaKGrr9rV7mLklznqYKN1Xn3oe0xSrTd06DxQo2IMe1-kT-DnseaxcW3WXsaYLo62feLzIvXmbQIOBg7kz4_BqNcVzVmIy9Q40SgQsp5MVGWoQn_feamwTvOjC9XjRykZo2m0WzOwJdesR53lYiw4RKC0jeOEgM6jV_Q_Rc_arCdKXOVtaVm2u2CUVmEyjOeJyo7gOwU");'>
</div>
<button class="absolute top-3 right-3 p-2 bg-white/80 dark:bg-black/50 backdrop-blur-sm rounded-full hover:bg-white text-gray-700 dark:text-white transition-colors">
<span class="material-symbols-outlined text-[20px]">favorite</span>
</button>
</div>
<div class="flex justify-between items-start">
<div>
<h4 class="font-bold text-text-main dark:text-white group-hover:text-primary transition-colors">Connecting Double Room</h4>
<p class="text-sm text-gray-500">Sleeps 4 • 650 sq ft</p>
</div>
<div class="text-right">
<p class="font-bold text-text-main dark:text-white">$199</p>
<p class="text-xs text-gray-500">/ night</p>
</div>
</div>
</div>
<!-- Card 3 -->
<div class="group cursor-pointer">
<div class="aspect-[4/3] w-full rounded-xl bg-gray-200 overflow-hidden relative mb-3">
<div class="absolute inset-0 bg-cover bg-center transition-transform duration-500 group-hover:scale-105" data-alt="Penthouse suite interior with large windows" style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuB9kSEowyaogujk6iOMOSuARyI25LkAPqJ39ZgGuXJD8hrDdNMcV815zn2UHs6rzVr_WL9Rau-As8D8xQ0pbprYIaU2sUBeQApCuQs0fgI0fIjbOj3W3s6HhMVRvhkDtOBe6WCVXR2V9cgVINU1t-vAStZA5SXC9OSnPpGJFkCMiXtq2vjVfY-DJAfaZPWTCuKZsvY8mYMukGujeDCtIYgY4Q2bqHKd_TuLBgThBrTJneq7uWJf_UyzpR3jByvyiokwmBIEfZbWgnE");'>
</div>
<button class="absolute top-3 right-3 p-2 bg-white/80 dark:bg-black/50 backdrop-blur-sm rounded-full hover:bg-white text-gray-700 dark:text-white transition-colors">
<span class="material-symbols-outlined text-[20px]">favorite</span>
</button>
</div>
<div class="flex justify-between items-start">
<div>
<h4 class="font-bold text-text-main dark:text-white group-hover:text-primary transition-colors">Ocean Penthouse</h4>
<p class="text-sm text-gray-500">Sleeps 6 • 1500 sq ft</p>
</div>
<div class="text-right">
<p class="font-bold text-text-main dark:text-white">$550</p>
<p class="text-xs text-gray-500">/ night</p>
</div>
</div>
</div>
</div>
</div>
</section>
<!-- Footer -->
<footer class="bg-background-light dark:bg-background-dark border-t border-gray-200 dark:border-white/10 py-10">
<div class="w-full flex justify-center px-6">
<div class="w-full max-w-[1280px] flex flex-col md:flex-row justify-between items-center gap-6">
<div class="flex items-center gap-4 text-text-main dark:text-white">
<div class="size-6 text-primary">
<span class="material-symbols-outlined text-[24px]">travel_explore</span>
</div>
<h2 class="text-lg font-bold">StayCation</h2>
</div>
<div class="flex gap-6 text-sm text-gray-500 dark:text-gray-400">
<a class="hover:text-primary transition-colors" href="#">Privacy Policy</a>
<a class="hover:text-primary transition-colors" href="#">Terms of Service</a>
<a class="hover:text-primary transition-colors" href="#">Cookies</a>
</div>
<div class="text-sm text-gray-400 dark:text-gray-600">
                        © 2023 StayCation Inc. All rights reserved.
                    </div>
</div>
</div>
</footer>
</div>
</body></html><?php /**PATH C:\Users\TRUNG NGHIA\Downloads\UEF_QLDAPM_B02E_G06-main\UEF_QLDAPM_B02E_G06\resources\views/pages/family-room.blade.php ENDPATH**/ ?>