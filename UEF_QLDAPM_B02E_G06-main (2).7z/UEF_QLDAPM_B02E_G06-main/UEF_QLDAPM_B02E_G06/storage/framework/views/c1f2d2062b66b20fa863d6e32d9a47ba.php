<!DOCTYPE html>
<html class="light" lang="en"><head>
<meta charset="utf-8"/>
<meta content="width=device-width, initial-scale=1.0" name="viewport"/>
<title>Tiệc Cưới Nhỏ - Small Wedding Events</title>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&amp;display=swap" rel="stylesheet"/>
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&amp;display=swap" rel="stylesheet"/>
<script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
<script id="tailwind-config">
        tailwind.config = {
            darkMode: "class",
            theme: {
                extend: {
                    colors: {
                        "primary": "#13ec13",
                        "background-light": "#f6f8f6",
                        "background-dark": "#102210",
                    },
                    fontFamily: {
                        "display": ["Plus Jakarta Sans", "sans-serif"]
                    },
                    borderRadius: {"DEFAULT": "0.25rem", "lg": "0.5rem", "xl": "0.75rem", "full": "9999px"},
                },
            },
        }
    </script>
<style>
        .material-symbols-outlined {
            font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24;
        }
        .hide-scroll::-webkit-scrollbar {
            display: none;
        }
        .hide-scroll {
            -ms-overflow-style: none;
            scrollbar-width: none;
        }
    </style>
</head>
<body class="bg-background-light dark:bg-background-dark font-display text-[#0d1b0d] dark:text-[#f8fcf8] antialiased">
<header class="sticky top-0 z-50 w-full border-b border-[#e7f3e7] dark:border-[#1a331a] bg-background-light/95 dark:bg-background-dark/95 backdrop-blur-sm">
<div class="flex items-center justify-between px-6 py-4 lg:px-10 max-w-[1440px] mx-auto">
<div class="flex items-center gap-4">
<div class="flex items-center gap-2 text-primary">
<span class="material-symbols-outlined text-3xl">forest</span>
</div>
<h2 class="text-xl font-bold tracking-tight text-[#0d1b0d] dark:text-white">Khu Retreats</h2>
</div>
<div class="hidden md:flex flex-1 justify-end gap-8 items-center">
<nav class="flex items-center gap-8">
<a class="text-sm font-medium hover:text-primary transition-colors" href="#">Stays</a>
<a class="text-sm font-medium hover:text-primary transition-colors" href="#">Events</a>
<a class="text-sm font-medium hover:text-primary transition-colors" href="#">Weddings</a>
<a class="text-sm font-medium hover:text-primary transition-colors" href="#">Contact</a>
</nav>
<div class="flex gap-3">
<button class="flex items-center justify-center rounded-lg h-10 px-4 bg-transparent hover:bg-[#e7f3e7] dark:hover:bg-[#1a331a] text-sm font-bold transition-colors">
                    Sign In
                </button>
<button class="flex items-center justify-center rounded-lg h-10 px-5 bg-primary hover:bg-opacity-90 text-[#0d1b0d] text-sm font-bold transition-colors shadow-sm">
                    Plan Event
                </button>
</div>
</div>
<button class="md:hidden text-[#0d1b0d] dark:text-white">
<span class="material-symbols-outlined">menu</span>
</button>
</div>
</header>
<main class="w-full max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 py-6">
<div class="flex flex-wrap items-center gap-2 text-sm font-medium text-[#4c9a4c] mb-6">
<a class="hover:underline" href="#">Home</a>
<span class="text-[#0d1b0d]/40 dark:text-white/40">/</span>
<a class="hover:underline" href="#">Events</a>
<span class="text-[#0d1b0d]/40 dark:text-white/40">/</span>
<span class="text-[#0d1b0d] dark:text-white">Tiệc Cưới Nhỏ (Small Wedding)</span>
</div>
<div class="flex flex-col gap-4 mb-6">
<div class="flex flex-col md:flex-row md:justify-between md:items-start gap-4">
<div>
<h1 class="text-3xl md:text-4xl font-black tracking-tight text-[#0d1b0d] dark:text-white mb-2">
                    Tiệc Cưới Nhỏ - Intimate Forest Wedding
                </h1>
<div class="flex items-center gap-2 text-sm text-[#0d1b0d]/80 dark:text-white/80">
<span class="flex items-center gap-1 font-bold">
<span class="material-symbols-outlined text-primary text-lg" style="font-variation-settings: 'FILL' 1;">star</span>
                            5.0
                        </span>
<span>·</span>
<a class="underline font-semibold hover:text-primary" href="#reviews">42 weddings hosted</a>
<span>·</span>
<span class="flex items-center gap-1">
                            Highland Forest Reserve
                        </span>
</div>
</div>
<div class="flex gap-3">
<button class="flex items-center gap-2 text-sm font-semibold px-4 py-2 rounded-lg hover:bg-[#e7f3e7] dark:hover:bg-[#1a331a] transition-colors">
<span class="material-symbols-outlined text-lg">share</span>
                    Share
                </button>
<button class="flex items-center gap-2 text-sm font-semibold px-4 py-2 rounded-lg hover:bg-[#e7f3e7] dark:hover:bg-[#1a331a] transition-colors">
<span class="material-symbols-outlined text-lg">favorite</span>
                    Save
                </button>
</div>
</div>
</div>
<div class="grid grid-cols-1 md:grid-cols-4 grid-rows-2 gap-3 h-[400px] md:h-[500px] rounded-2xl overflow-hidden mb-10 relative group/gallery">
<div class="md:col-span-2 md:row-span-2 relative h-full bg-neutral-200">
<div class="w-full h-full bg-cover bg-center hover:scale-105 transition-transform duration-500 cursor-pointer" data-alt="Romantic outdoor wedding ceremony setup in forest" style="background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuDa1oyVnz9Doaz-4jtFIPkc_eDRgxyBk0uyU0sfRTQzTT_6vzQQn_bFfa59EzNtTKZJV_k_LK4Mv3v8EYGMfF9wGoNS7sLDEjeSgWQohMfAMZCW8xkESOHj40j9FwN6QQIr9J-T-FbcLWoU90HF9rDXvzxOGZphvgPkmTWSBZPzI2T3tDlgfmalp4c7jbxow1Imqr9c20mjQrE0uyjLfJ7W-wzI95qa5GLTQvma5f9j7sBBYR_kDRVeJMq0zxb6m-earjna9U3_cKA');"></div>
</div>
<div class="md:col-span-1 md:row-span-1 relative h-full bg-neutral-200">
<div class="w-full h-full bg-cover bg-center hover:scale-105 transition-transform duration-500 cursor-pointer" data-alt="Intimate dinner table setup with candles" style="background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuAFdzcRdSm5XT-nYMSD_rbz11kYyMOwAeuTNeQsmAbUGojFaOGpDZutgmVhlVUPFUlOLDnYTlPbDHE0GCInJmvQ8ku_2gP9HgoJpo3zwboSLfVZAER2B2S3sYd-VWP8eQh978iKC00QEqOE7SMHpgdvmSGonnesFCh2nkF6wUyitFhxZMai1a35FfhsWyevGSTWbMRfd3UlBJcVFKV7Fmvt4LXJ3JVoqEcPf-GLHtfVdI_C2BNyrH2fkJn_9OrAYmwtLRSCL-k2xR4');"></div>
</div>
<div class="md:col-span-1 md:row-span-1 relative h-full bg-neutral-200">
<div class="w-full h-full bg-cover bg-center hover:scale-105 transition-transform duration-500 cursor-pointer" data-alt="Bridal suite interior" style="background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuBMaZLJsnS8SSoTtrSqCu0bM2F_Ui16WUWZ3KeEo_BPuHErySE-bqUCjaISrJNkmkI29ZsKwtOxM2JmVZOHbh7mZR80uSFs59ZG_Ju9Dv9R6lHJschUA1KxuRdUINwZ9uIURh5NF5AAsyXaCLzRy1E7fFafcr5Yj_aY5Rfrcwdghrlmxp45B3pUp22rP7Y-TCuvPMlO_M0L2IppCfrcIFmS3STwfn71EjdcjCw8U3jyXgtNFbnrwn_A7t3QA3CUqlKAjWK3RxbrPio');"></div>
</div>
<div class="md:col-span-1 md:row-span-1 relative h-full bg-neutral-200">
<div class="w-full h-full bg-cover bg-center hover:scale-105 transition-transform duration-500 cursor-pointer" data-alt="Wedding catering preparation area" style="background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuBaiM8xDIH5vlv19XTaOAOyS52vaNTava75Hd1IMfQMfL234AG1DQ2k70uKQ4nfdU9ca0vtXanOus5P6Z1aaQQ19Ec63haeMpdUmF_GrNWFKLM2IagE6OEBhONjNsr0F4riF4eqvvurH-FriaRmC9owoF3T8wKV1XBqdejog_bTZsmhrvaioOQxvmTPOvFyrqPr-PKzUbst9OorG5-1AkncmCo2ImsIUmwQpEax1TMxcjg3fvbcud20dbY5kegxwXOEisab2vfABIk');"></div>
</div>
<div class="md:col-span-1 md:row-span-1 relative h-full bg-neutral-200">
<div class="w-full h-full bg-cover bg-center hover:scale-105 transition-transform duration-500 cursor-pointer" data-alt="Outdoor deck for cocktail hour" style="background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuAC4YXDTvtuHpmkTjliXcnyOl1YSsO-lDLiYXvk7yNIbPT1g9ereV-JWHiEhE_QEAKpI8jwCovZ7RSjC1c6c09seFlXyoPd6tmA4lSU4jgurd5V8qweJRW3cbKG21xd3jaVUKZu0BTORdt9zNL8FP1f5KW59DsA1r1ssoF2K5T5AW0VHgFNP7eMaYI0FJ6oQrDrV8QVKFCY-G8Dy6dGE9aKckl1tujmxmhzv6QCO6wYxXK7vrLLWRtfYaVmnEHj8QN9fIVEckl1wFA');"></div>
<button class="absolute bottom-4 right-4 bg-white dark:bg-[#1a331a] text-xs font-bold px-3 py-2 rounded-lg shadow-md hover:scale-105 transition flex items-center gap-2 border border-gray-200 dark:border-gray-800">
<span class="material-symbols-outlined text-base">grid_view</span>
                View gallery
            </button>
</div>
</div>
<div class="grid grid-cols-1 lg:grid-cols-3 gap-12 relative">
<div class="lg:col-span-2 flex flex-col gap-10">
<div class="flex justify-between items-center border-b border-[#e7f3e7] dark:border-[#1a331a] pb-8">
<div class="flex flex-col gap-1">
<h2 class="text-xl font-bold">Planned by Khu Events Team</h2>
<span class="text-base text-[#0d1b0d]/70 dark:text-white/70">Up to 50 guests · Full Catering · Decor Included</span>
</div>
<div class="size-14 rounded-full overflow-hidden bg-gray-200 border-2 border-primary p-0.5">
<div class="w-full h-full rounded-full bg-cover bg-center" data-alt="Portrait of the event planner" style="background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuD3W_7F2E4sqRpbFzNPgE3vmfcTBpFLLblPJjr_vmOeGWI6y9qTaMW41Sztty7AJobiVMt0Hdyh1uzX5FqIP9K7GhGW7B5n196DqLL-SF8pvNa0Eg_U3M-NXJanLzwrbmrGgMmXzD1fyFecIzsnDeyUEheEKEjlRwZ07Z5t0WImn-NYPfkPIQHneqc2-Wl5_iXyGgwtnP73jylXL7y1HAiCE6FK6S6esIvMZbo6xC5kEG_Lae9nX-OKLR_NoZKaSs-X7IwnKXsi5lc')"></div>
</div>
</div>
<div class="flex flex-col gap-6">
<div class="flex gap-4">
<span class="material-symbols-outlined text-2xl mt-1 text-primary">favorite</span>
<div>
<h3 class="font-bold text-lg">Romantic Atmosphere</h3>
<p class="text-sm text-[#0d1b0d]/70 dark:text-white/70">A secluded sanctuary designed for intimate moments and emotional exchanges.</p>
</div>
</div>
<div class="flex gap-4">
<span class="material-symbols-outlined text-2xl mt-1 text-primary">forest</span>
<div>
<h3 class="font-bold text-lg">Natural Backdrop</h3>
<p class="text-sm text-[#0d1b0d]/70 dark:text-white/70">Exchange vows under the canopy of ancient pine trees with misty mountain views.</p>
</div>
</div>
<div class="flex gap-4">
<span class="material-symbols-outlined text-2xl mt-1 text-primary">diamond</span>
<div>
<h3 class="font-bold text-lg">All-Inclusive Service</h3>
<p class="text-sm text-[#0d1b0d]/70 dark:text-white/70">From floral arrangements to fine dining, we handle every detail.</p>
</div>
</div>
</div>
<div class="border-b border-[#e7f3e7] dark:border-[#1a331a]"></div>
<div>
<h2 class="text-2xl font-bold mb-4">About this event</h2>
<div class="space-y-4 text-base leading-relaxed text-[#0d1b0d]/80 dark:text-white/80">
<p>
                        Celebrate your love in the serene embrace of the Highland Forest. The "Tiệc Cưới Nhỏ" (Small Wedding) package is specifically curated for couples seeking a meaningful, intimate celebration away from the hustle of the city. We believe that small weddings allow for bigger moments.
                    </p>
<p>
                        Our venue, the Khu Wooden House, serves as the perfect rustic-chic backdrop. Whether you prefer a twilight ceremony on the deck or a barefoot exchange of vows on the forest floor, our dedicated team transforms the space to reflect your unique story.
                    </p>
<p>
                        Post-ceremony, enjoy a chef-prepared intimate dinner at a long wooden table adorned with local wildflowers and candlelight, creating memories that will last a lifetime.
                    </p>
</div>
<button class="mt-4 flex items-center gap-1 font-bold underline decoration-primary decoration-2 underline-offset-4 hover:opacity-80">
                    Read more <span class="material-symbols-outlined text-lg">chevron_right</span>
</button>
</div>
<div class="border-b border-[#e7f3e7] dark:border-[#1a331a]"></div>
<div>
<h2 class="text-2xl font-bold mb-6">Wedding Services Included</h2>
<div class="grid grid-cols-1 md:grid-cols-2 gap-y-4 gap-x-12">
<div class="flex items-center gap-4">
<span class="material-symbols-outlined text-2xl text-[#0d1b0d]/60 dark:text-white/60">local_florist</span>
<span class="text-base">Custom Floral Design</span>
</div>
<div class="flex items-center gap-4">
<span class="material-symbols-outlined text-2xl text-[#0d1b0d]/60 dark:text-white/60">restaurant</span>
<span class="text-base">Fine Dining Menu</span>
</div>
<div class="flex items-center gap-4">
<span class="material-symbols-outlined text-2xl text-[#0d1b0d]/60 dark:text-white/60">photo_camera</span>
<span class="text-base">Professional Photography</span>
</div>
<div class="flex items-center gap-4">
<span class="material-symbols-outlined text-2xl text-[#0d1b0d]/60 dark:text-white/60">queue_music</span>
<span class="text-base">Sound &amp; Acoustic Music</span>
</div>
<div class="flex items-center gap-4">
<span class="material-symbols-outlined text-2xl text-[#0d1b0d]/60 dark:text-white/60">cake</span>
<span class="text-base">Wedding Cake</span>
</div>
<div class="flex items-center gap-4">
<span class="material-symbols-outlined text-2xl text-[#0d1b0d]/60 dark:text-white/60">celebration</span>
<span class="text-base">Champagne Toast</span>
</div>
<div class="flex items-center gap-4">
<span class="material-symbols-outlined text-2xl text-[#0d1b0d]/60 dark:text-white/60">chair</span>
<span class="text-base">Ceremony Seating</span>
</div>
<div class="flex items-center gap-4">
<span class="material-symbols-outlined text-2xl text-[#0d1b0d]/60 dark:text-white/60">bed</span>
<span class="text-base">Bridal Suite Night</span>
</div>
</div>
<button class="mt-8 border border-black dark:border-white rounded-lg px-6 py-3 font-semibold hover:bg-black/5 dark:hover:bg-white/10 transition">
                    Download Services Brochure
                </button>
</div>
<div class="border-b border-[#e7f3e7] dark:border-[#1a331a]"></div>
<div>
<h2 class="text-2xl font-bold mb-6">Our Packages</h2>
<div class="grid grid-cols-1 md:grid-cols-2 gap-6">
<div class="bg-white dark:bg-[#152a15] border border-[#e7f3e7] dark:border-[#1a331a] rounded-xl p-6 shadow-sm hover:shadow-md transition">
<h3 class="text-lg font-bold mb-2">The Elopement</h3>
<div class="text-2xl font-bold text-primary mb-4">$1,500</div>
<p class="text-sm text-[#0d1b0d]/60 dark:text-white/60 mb-4">Perfect for just the couple or up to 4 guests.</p>
<ul class="space-y-2 text-sm text-[#0d1b0d]/80 dark:text-white/80 mb-6">
<li class="flex items-center gap-2"><span class="material-symbols-outlined text-primary text-sm">check</span> 2 Hours Venue Use</li>
<li class="flex items-center gap-2"><span class="material-symbols-outlined text-primary text-sm">check</span> Ceremony Arch Decor</li>
<li class="flex items-center gap-2"><span class="material-symbols-outlined text-primary text-sm">check</span> Officiant</li>
<li class="flex items-center gap-2"><span class="material-symbols-outlined text-primary text-sm">check</span> Champagne Toast</li>
</ul>
</div>
<div class="bg-white dark:bg-[#152a15] border-2 border-primary rounded-xl p-6 shadow-md relative">
<div class="absolute -top-3 right-4 bg-primary text-[#0d1b0d] text-xs font-bold px-3 py-1 rounded-full">MOST POPULAR</div>
<h3 class="text-lg font-bold mb-2">Intimate Gathering</h3>
<div class="text-2xl font-bold text-primary mb-4">$3,500</div>
<p class="text-sm text-[#0d1b0d]/60 dark:text-white/60 mb-4">A complete celebration for up to 20 guests.</p>
<ul class="space-y-2 text-sm text-[#0d1b0d]/80 dark:text-white/80 mb-6">
<li class="flex items-center gap-2"><span class="material-symbols-outlined text-primary text-sm">check</span> 6 Hours Venue Use</li>
<li class="flex items-center gap-2"><span class="material-symbols-outlined text-primary text-sm">check</span> Full Ceremony &amp; Reception Decor</li>
<li class="flex items-center gap-2"><span class="material-symbols-outlined text-primary text-sm">check</span> 3-Course Dinner</li>
<li class="flex items-center gap-2"><span class="material-symbols-outlined text-primary text-sm">check</span> Photographer (4 Hours)</li>
</ul>
</div>
</div>
</div>
</div>
<div class="lg:col-span-1 relative">
<div class="sticky top-28 w-full">
<div class="bg-white dark:bg-[#152a15] rounded-2xl shadow-xl border border-[#e7f3e7] dark:border-[#1a331a] p-6">
<div class="flex justify-between items-end mb-6">
<div>
<span class="text-sm text-[#0d1b0d]/60 dark:text-white/60">Packages from</span>
<div class="text-2xl font-bold">$1,500</div>
</div>
<div class="flex items-center gap-1 text-sm">
<span class="material-symbols-outlined text-primary text-sm" style="font-variation-settings: 'FILL' 1;">star</span>
<span class="font-bold">5.0</span>
<span class="text-gray-400">·</span>
<span class="text-gray-500 underline decoration-gray-400">42 reviews</span>
</div>
</div>
<div class="border border-gray-300 dark:border-gray-600 rounded-xl overflow-hidden mb-4">
<div class="p-3 border-b border-gray-300 dark:border-gray-600">
<label class="block text-[10px] font-bold uppercase tracking-wider text-[#0d1b0d] dark:text-white">Preferred Date</label>
<div class="text-sm flex justify-between items-center cursor-pointer">
<span>Select a date</span>
<span class="material-symbols-outlined text-lg">calendar_month</span>
</div>
</div>
<div class="p-3 relative">
<label class="block text-[10px] font-bold uppercase tracking-wider text-[#0d1b0d] dark:text-white">Guest Count</label>
<div class="text-sm flex justify-between items-center cursor-pointer">
<span>20 - 30 Guests</span>
<span class="material-symbols-outlined text-xl">expand_more</span>
</div>
</div>
</div>
<button class="w-full bg-primary hover:bg-[#0fd60f] text-[#0d1b0d] font-bold py-3.5 rounded-xl text-lg transition-all transform active:scale-[0.98] mb-4">
                        Request Consultation
                    </button>
<p class="text-center text-sm text-[#0d1b0d]/60 dark:text-white/60 mb-6">Free initial consultation call</p>
<div class="flex flex-col gap-3 text-sm md:text-base">
<div class="flex justify-between text-[#0d1b0d]/80 dark:text-white/80">
<span class="underline decoration-gray-300">Intimate Gathering Pkg</span>
<span>$3,500</span>
</div>
<div class="flex justify-between text-[#0d1b0d]/80 dark:text-white/80">
<span class="underline decoration-gray-300">Service Fee (10%)</span>
<span>$350</span>
</div>
<div class="flex justify-between text-[#0d1b0d]/80 dark:text-white/80">
<span class="underline decoration-gray-300">Est. Tax</span>
<span>$280</span>
</div>
</div>
<div class="my-6 border-t border-[#e7f3e7] dark:border-[#1a331a]"></div>
<div class="flex justify-between font-bold text-lg">
<span>Est. Total</span>
<span>$4,130</span>
</div>
</div>
<div class="mt-4 flex justify-center gap-2 items-center text-sm text-[#0d1b0d]/50 dark:text-white/50">
<span class="material-symbols-outlined text-base">chat</span>
<a class="underline hover:text-[#0d1b0d] dark:hover:text-white" href="#">Chat with a planner</a>
</div>
</div>
</div>
</div>
<div class="border-b border-[#e7f3e7] dark:border-[#1a331a] my-12"></div>
<section class="mb-12" id="reviews">
<div class="flex items-center gap-2 mb-8">
<span class="material-symbols-outlined text-primary text-3xl" style="font-variation-settings: 'FILL' 1;">star</span>
<h2 class="text-2xl font-bold">5.0 · 42 wedding reviews</h2>
</div>
<div class="grid grid-cols-1 md:grid-cols-2 gap-8">
<div class="flex flex-col gap-4">
<div class="flex items-center gap-3">
<div class="size-12 rounded-full bg-gray-200 overflow-hidden">
<div class="w-full h-full bg-cover bg-center" data-alt="Reviewer avatar" style="background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuCIuDmbaeWkddKXGutG8o0Ndfx6Trt0hdk_aiRyecdlJ6Gajwc2KL9TK2BwteORB7YA2MZ0yujcolLKNReLGe8jQM2t6Y73gep8TeLKAiRytOoJNmX7JoZBpAWSfXMbeQd0BsNByAaJiwZh7_ZGiwQjMX5I5lR0IqwuyQg0f4WuQMOoDoTFPjEF5Ao5TEgpqKZrvJm3eup1DTvWXVohf4qaDKWEErMv9-9g91RuQo-G1EWt85spNsp_mw4df88wtoqKLi6CQo3YkfY')"></div>
</div>
<div>
<div class="font-bold">Emily &amp; James</div>
<div class="text-sm text-[#0d1b0d]/60 dark:text-white/60">Married February 2024</div>
</div>
</div>
<p class="text-[#0d1b0d]/80 dark:text-white/80 leading-relaxed">
                    "Our wedding at Khu was everything we dreamed of. The 'Small Wedding' package was perfect for our 30 guests. The team handled everything from the flowers to the music, so we could just focus on each other. The forest setting was magical."
                </p>
</div>
<div class="flex flex-col gap-4">
<div class="flex items-center gap-3">
<div class="size-12 rounded-full bg-gray-200 overflow-hidden">
<div class="w-full h-full bg-cover bg-center" data-alt="Reviewer avatar" style="background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuAxTGKPB_3H4V8sMME6FzJH-1p8M68N0971xe8hsunrRjU0F1Ir-N2dMWvXLPNh9Q7U2zovBONJJiNyV3K50FfE0XSij58q4ez7y_glcT0TYadiTmJBLU0qOmjwERiGsU0e8A0XEu15tmrtrx7_0pxF31ws1oWxqkuL_R_DR_EQTcBsytFlLLIqgzzBwMYLwJ7LEVVNr8PE2cFrVX4OZfO8uvhjYKP_xntP78gf9O9wZmkm3gPTNjnn0SJHjs2BWplqLZL-rpPv-yQ')"></div>
</div>
<div>
<div class="font-bold">Sarah &amp; Linh</div>
<div class="text-sm text-[#0d1b0d]/60 dark:text-white/60">Married January 2024</div>
</div>
</div>
<p class="text-[#0d1b0d]/80 dark:text-white/80 leading-relaxed">
                    "If you want a private, romantic ceremony, this is the place. The food was incredible - our guests are still talking about the dinner. The coordinator, Sarah, was so helpful throughout the planning process."
                </p>
</div>
</div>
<button class="mt-8 border border-black dark:border-white rounded-lg px-6 py-3 font-semibold hover:bg-black/5 dark:hover:bg-white/10 transition">
            Show all 42 reviews
        </button>
</section>
<div class="border-b border-[#e7f3e7] dark:border-[#1a331a] my-12"></div>
<section class="mb-12">
<h2 class="text-2xl font-bold mb-2">The Venue Location</h2>
<p class="text-[#0d1b0d]/70 dark:text-white/70 mb-6">Highland Region, Country</p>
<div class="w-full h-[480px] rounded-xl bg-gray-200 relative overflow-hidden group">
<div class="w-full h-full bg-cover bg-center" data-alt="Map view showing the location of the cabin in a dense forest region" data-location="Highland Region Map View" style="background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuDFrvITJw83pqzEk_7VctE26T1LCJR8EYOMhNTpSHmWZPzcXjKjvxeNtF8GWm5xIHg58ryuzx37bvm0EnORRAi6iqPObc-ZxQ1T77wN2sN15eVEWt0-THk7Z4MUn4WofCy0el2-ZCifbiggQGlU8l2OyatXqHjVRV3oOSFK-LaNGt0k6d68ZodFA41WR0Stazy6RQvx6Pxb-obHoQRQHZXVIpRCtVRk_-sXpsrzJOqSlueaCtQue8vZMi38qTCO6GD0vfWwbWEiR6w'); filter: grayscale(20%);">
</div>
<div class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center">
<div class="size-12 bg-primary rounded-full flex items-center justify-center shadow-lg animate-bounce">
<span class="material-symbols-outlined text-white text-3xl" style="font-variation-settings: 'FILL' 1;">location_on</span>
</div>
<div class="mt-2 bg-white dark:bg-[#1a331a] px-4 py-2 rounded-lg shadow-lg font-bold text-sm">
                    Private Forest Estate
                </div>
</div>
<div class="absolute bottom-4 right-4 flex gap-2">
<button class="bg-white dark:bg-[#1a331a] p-2 rounded shadow hover:bg-gray-100">
<span class="material-symbols-outlined">add</span>
</button>
<button class="bg-white dark:bg-[#1a331a] p-2 rounded shadow hover:bg-gray-100">
<span class="material-symbols-outlined">remove</span>
</button>
</div>
</div>
<div class="mt-6">
<h3 class="font-bold text-lg mb-2">Getting Here</h3>
<p class="text-[#0d1b0d]/70 dark:text-white/70 max-w-3xl">
                The venue is located in the heart of the Highland Forest Reserve, ensuring complete privacy for your event. Shuttle services for guests can be arranged from the nearest town (20 mins away) as part of your wedding package. Ample parking is available on-site.
            </p>
</div>
</section>
</main>
<footer class="bg-[#f8fcf8] dark:bg-[#0c1a0c] border-t border-[#e7f3e7] dark:border-[#1a331a] py-12">
<div class="max-w-[1280px] mx-auto px-6 lg:px-8">
<div class="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
<div>
<h3 class="font-bold mb-4">Event Support</h3>
<ul class="space-y-3 text-sm text-[#0d1b0d]/70 dark:text-white/70">
<li><a class="hover:underline" href="#">Planning Guide</a></li>
<li><a class="hover:underline" href="#">Vendor List</a></li>
<li><a class="hover:underline" href="#">Decor Options</a></li>
<li><a class="hover:underline" href="#">Menu Tasting</a></li>
<li><a class="hover:underline" href="#">Cancellation Policy</a></li>
</ul>
</div>
<div>
<h3 class="font-bold mb-4">Venue Info</h3>
<ul class="space-y-3 text-sm text-[#0d1b0d]/70 dark:text-white/70">
<li><a class="hover:underline" href="#">Virtual Tour</a></li>
<li><a class="hover:underline" href="#">Capacity Chart</a></li>
<li><a class="hover:underline" href="#">Accommodation</a></li>
<li><a class="hover:underline" href="#">Weather Info</a></li>
<li><a class="hover:underline" href="#">Map &amp; Directions</a></li>
</ul>
</div>
<div>
<h3 class="font-bold mb-4">Khu Retreats</h3>
<ul class="space-y-3 text-sm text-[#0d1b0d]/70 dark:text-white/70">
<li><a class="hover:underline" href="#">Our Story</a></li>
<li><a class="hover:underline" href="#">Gallery</a></li>
<li><a class="hover:underline" href="#">Careers</a></li>
<li><a class="hover:underline" href="#">Press</a></li>
<li><a class="hover:underline" href="#">Contact Us</a></li>
</ul>
</div>
<div>
<div class="flex flex-col gap-4">
<button class="bg-primary hover:bg-[#0fd60f] text-[#0d1b0d] font-bold py-3 rounded-lg text-sm w-full transition-colors">
                        Download Brochure
                    </button>
<p class="text-xs text-[#0d1b0d]/50 dark:text-white/50">
                        Get our full wedding brochure with detailed pricing and package inclusions.
                    </p>
</div>
</div>
</div>
<div class="border-t border-[#e7f3e7] dark:border-[#1a331a] pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
<div class="flex items-center gap-2 text-sm text-[#0d1b0d]/70 dark:text-white/70">
<span>© 2024 Khu Retreats, Inc.</span>
<span>·</span>
<a class="hover:underline" href="#">Privacy</a>
<span>·</span>
<a class="hover:underline" href="#">Terms</a>
<span>·</span>
<a class="hover:underline" href="#">Sitemap</a>
</div>
<div class="flex gap-4">
<span class="material-symbols-outlined cursor-pointer hover:text-primary transition-colors">language</span>
<span class="text-sm font-bold cursor-pointer hover:text-primary transition-colors">English (US)</span>
<span class="text-sm font-bold cursor-pointer hover:text-primary transition-colors">$ USD</span>
</div>
</div>
</div>
</footer>

</body></html><?php /**PATH C:\Users\TRUNG NGHIA\Downloads\UEF_QLDAPM_B02E_G06-main\UEF_QLDAPM_B02E_G06\resources\views/pages/tiec-cuoi-nho.blade.php ENDPATH**/ ?>